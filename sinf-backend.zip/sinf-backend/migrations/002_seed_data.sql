-- =====================================================
-- Sinf Platform - Seed Data
-- =====================================================

BEGIN;

-- =====================================================
-- 1. SEED CATEGORIES
-- =====================================================
INSERT INTO categories (name_ar, name_en, description_ar, description_en, icon) VALUES
('المفكرون', 'Thinkers', 'الأشخاص الذين يحبون التفكير العميق والتحليل', 'People who love deep thinking and analysis', '🧠'),
('المبدعون', 'Creators', 'الأشخاص الذين يحبون الإبداع والفن', 'People who love creativity and art', '🎨'),
('الاجتماعيون', 'Socializers', 'الأشخاص الذين يحبون التواصل والعلاقات', 'People who love communication and relationships', '👥'),
('المغامرون', 'Adventurers', 'الأشخاص الذين يحبون المغامرة والتجارب الجديدة', 'People who love adventure and new experiences', '🏔️'),
('القادة', 'Leaders', 'الأشخاص الذين يحبون القيادة وإدارة الآخرين', 'People who love leadership and managing others', '👑'),
('المساعدون', 'Helpers', 'الأشخاص الذين يحبون مساعدة الآخرين', 'People who love helping others', '🤝'),
('المنظمون', 'Organizers', 'الأشخاص الذين يحبون التنظيم والترتيب', 'People who love organization and order', '📋'),
('الباحثون', 'Researchers', 'الأشخاص الذين يحبون البحث والاستكشاف', 'People who love research and exploration', '🔍');

-- =====================================================
-- 2. SEED CATEGORIZATION QUESTIONS
-- =====================================================
INSERT INTO categorization_questions (question_ar, question_en, question_type, options, category_weights, order_index) VALUES
(
    'كيف تفضل قضاء وقت فراغك؟',
    'How do you prefer to spend your free time?',
    'multiple_choice',
    '[
        {"value": "a", "text_ar": "القراءة والتفكير", "text_en": "Reading and thinking"},
        {"value": "b", "text_ar": "الرسم أو الكتابة", "text_en": "Drawing or writing"},
        {"value": "c", "text_ar": "مع الأصدقاء", "text_en": "With friends"},
        {"value": "d", "text_ar": "تجربة أشياء جديدة", "text_en": "Trying new things"}
    ]'::jsonb,
    '{
        "a": [{"category_id": 1, "weight": 5}, {"category_id": 8, "weight": 3}],
        "b": [{"category_id": 2, "weight": 5}],
        "c": [{"category_id": 3, "weight": 5}],
        "d": [{"category_id": 4, "weight": 5}]
    }'::jsonb,
    1
),
(
    'ما الذي يحفزك أكثر؟',
    'What motivates you the most?',
    'multiple_choice',
    '[
        {"value": "a", "text_ar": "حل المشكلات المعقدة", "text_en": "Solving complex problems"},
        {"value": "b", "text_ar": "إنشاء شيء جميل", "text_en": "Creating something beautiful"},
        {"value": "c", "text_ar": "مساعدة الآخرين", "text_en": "Helping others"},
        {"value": "d", "text_ar": "تحقيق الأهداف", "text_en": "Achieving goals"}
    ]'::jsonb,
    '{
        "a": [{"category_id": 1, "weight": 5}, {"category_id": 8, "weight": 3}],
        "b": [{"category_id": 2, "weight": 5}],
        "c": [{"category_id": 6, "weight": 5}],
        "d": [{"category_id": 5, "weight": 5}, {"category_id": 7, "weight": 3}]
    }'::jsonb,
    2
),
(
    'كيف تتخذ قراراتك؟',
    'How do you make decisions?',
    'multiple_choice',
    '[
        {"value": "a", "text_ar": "بالتحليل المنطقي", "text_en": "Through logical analysis"},
        {"value": "b", "text_ar": "بالحدس والشعور", "text_en": "Through intuition and feeling"},
        {"value": "c", "text_ar": "بالتشاور مع الآخرين", "text_en": "By consulting with others"},
        {"value": "d", "text_ar": "بسرعة وبشكل حاسم", "text_en": "Quickly and decisively"}
    ]'::jsonb,
    '{
        "a": [{"category_id": 1, "weight": 5}],
        "b": [{"category_id": 2, "weight": 4}, {"category_id": 4, "weight": 3}],
        "c": [{"category_id": 3, "weight": 5}],
        "d": [{"category_id": 5, "weight": 5}]
    }'::jsonb,
    3
),
(
    'ما هو أسلوب عملك المفضل؟',
    'What is your preferred work style?',
    'multiple_choice',
    '[
        {"value": "a", "text_ar": "منفرداً ومركزاً", "text_en": "Alone and focused"},
        {"value": "b", "text_ar": "بحرية وإبداع", "text_en": "Freely and creatively"},
        {"value": "c", "text_ar": "ضمن فريق", "text_en": "Within a team"},
        {"value": "d", "text_ar": "منظم ومخطط", "text_en": "Organized and planned"}
    ]'::jsonb,
    '{
        "a": [{"category_id": 1, "weight": 4}, {"category_id": 8, "weight": 4}],
        "b": [{"category_id": 2, "weight": 5}],
        "c": [{"category_id": 3, "weight": 5}],
        "d": [{"category_id": 7, "weight": 5}]
    }'::jsonb,
    4
),
(
    'ما الذي تقدره أكثر في الحياة؟',
    'What do you value most in life?',
    'multiple_choice',
    '[
        {"value": "a", "text_ar": "المعرفة والحكمة", "text_en": "Knowledge and wisdom"},
        {"value": "b", "text_ar": "الجمال والفن", "text_en": "Beauty and art"},
        {"value": "c", "text_ar": "العلاقات والصداقة", "text_en": "Relationships and friendship"},
        {"value": "d", "text_ar": "الإنجاز والنجاح", "text_en": "Achievement and success"}
    ]'::jsonb,
    '{
        "a": [{"category_id": 1, "weight": 5}, {"category_id": 8, "weight": 3}],
        "b": [{"category_id": 2, "weight": 5}],
        "c": [{"category_id": 3, "weight": 5}, {"category_id": 6, "weight": 3}],
        "d": [{"category_id": 5, "weight": 5}]
    }'::jsonb,
    5
);

COMMIT;
# Sinf Platform - Backend API

A scalable Go backend for the Sinf social platform with microservices architecture.

## Features

- **Authentication**: JWT-based auth with OTP verification
- **Real-time Communication**: WebSocket support for chat and notifications
- **File Storage**: S3-compatible object storage
- **Caching**: Redis for sessions and rate limiting
- **Database**: PostgreSQL with read replicas support
- **API**: RESTful API with versioning

## Tech Stack

- **Language**: Go 1.21+
- **Framework**: Gorilla Mux
- **Database**: PostgreSQL
- **Cache**: Redis
- **Storage**: AWS S3 / MinIO
- **WebSocket**: Gorilla WebSocket
- **Auth**: JWT tokens

## Project Structure

```
sinf-backend/
├── cmd/
│   └── server/          # Application entry point
├── internal/            # Private application code
│   ├── auth/           # Authentication service
│   ├── users/          # User management
│   ├── posts/          # Posts service
│   ├── comments/       # Comments service
│   ├── chat/           # Chat service
│   ├── points/         # Zizo points system
│   ├── store/          # Marketplace
│   ├── payments/       # Payment processing
│   ├── bots/           # Bot management
│   ├── admin/          # Admin panel
│   └── notifications/  # Notification service
├── pkg/                # Public reusable packages
│   ├── database/       # Database connections
│   ├── redis/          # Redis client
│   ├── jwt/            # JWT utilities
│   ├── websocket/      # WebSocket hub
│   └── storage/        # S3 storage
├── migrations/         # Database migrations
└── config/            # Configuration

## Getting Started

### Prerequisites

- Go 1.21 or higher
- PostgreSQL 14+
- Redis 7+
- AWS S3 or MinIO (for file storage)

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd sinf-backend
```

2. Install dependencies:
```bash
go mod download
```

3. Copy environment file:
```bash
cp .env.example .env
```

4. Configure environment variables in `.env`:
```env
# Server
PORT=8080

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/sinf?sslmode=disable

# Redis
REDIS_URL=redis://localhost:6379/0

# JWT
JWT_SECRET=your-super-secret-jwt-key-change-this

# AWS S3
AWS_REGION=us-east-1
AWS_BUCKET_NAME=sinf-storage
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key

# SMTP (for emails)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM=noreply@sinf.com
```

5. Run database migrations:
```bash
# Install migrate tool
go install -tags 'postgres' github.com/golang-migrate/migrate/v4/cmd/migrate@latest

# Run migrations
migrate -path migrations -database "postgresql://user:password@localhost:5432/sinf?sslmode=disable" up
```

6. Run the server:
```bash
go run cmd/server/main.go
```

The server will start on `http://localhost:8080`

## API Documentation

### Authentication

#### Register
```http
POST /api/v1/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "+213XXXXXXXXX",
  "password": "SecurePass123!"
}
```

#### Verify OTP
```http
POST /api/v1/auth/verify-otp
Content-Type: application/json

{
  "user_id": "uuid",
  "otp": "123456"
}
```

#### Login
```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "email_or_phone": "john@example.com",
  "password": "SecurePass123!"
}
```

#### Forgot Password
```http
POST /api/v1/auth/forgot-password
Content-Type: application/json

{
  "email_or_phone": "john@example.com"
}
```

#### Reset Password
```http
POST /api/v1/auth/reset-password
Content-Type: application/json

{
  "user_id": "uuid",
  "otp": "123456",
  "new_password": "NewSecurePass123!"
}
```

### Health Check
```http
GET /health
```

## Development

### Running Tests
```bash
go test ./...
```

### Building
```bash
go build -o bin/server cmd/server/main.go
```

### Docker
```bash
docker build -t sinf-backend .
docker run -p 8080:8080 --env-file .env sinf-backend
```

## Deployment

### Production Checklist

- [ ] Set strong JWT_SECRET
- [ ] Configure database with SSL
- [ ] Set up Redis cluster
- [ ] Configure S3 bucket policies
- [ ] Enable HTTPS
- [ ] Set up monitoring (Prometheus + Grafana)
- [ ] Configure logging (ELK stack)
- [ ] Set up CI/CD pipeline
- [ ] Configure auto-scaling
- [ ] Set up database backups

### Kubernetes Deployment

See `k8s/` directory for Kubernetes manifests.

## Architecture

The backend follows a microservices-inspired architecture with:

- **API Gateway**: Routes requests to appropriate services
- **Service Layer**: Business logic
- **Repository Layer**: Data access
- **WebSocket Hub**: Real-time communication
- **Background Workers**: Async task processing (Kafka consumers)

## Security

- Passwords hashed with bcrypt
- JWT tokens with short expiry
- Rate limiting on all endpoints
- Input validation and sanitization
- SQL injection protection (prepared statements)
- XSS protection
- CORS configuration
- Audit logging for sensitive operations

## Monitoring

- Prometheus metrics endpoint: `/metrics`
- Health check endpoint: `/health`
- Structured logging with request IDs
- Error tracking with Sentry

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

Proprietary - All rights reserved

## Support

For issues and questions, contact: support@sinf.com
package config

import (
	"log"
	"os"
	"strconv"
	"time"

	"github.com/joho/godotenv"
)

type Config struct {
	Server   ServerConfig
	Database DatabaseConfig
	Redis    RedisConfig
	JWT      JWTConfig
	S3       S3Config
	Payment  PaymentConfig
	SMS      SMSConfig
	Email    EmailConfig
	RateLimit RateLimitConfig
	CORS     CORSConfig
	Bot      BotConfig
	Points   PointsConfig
}

type ServerConfig struct {
	Port       string
	Env        string
	APIVersion string
}

type DatabaseConfig struct {
	Host     string
	Port     string
	User     string
	Password string
	DBName   string
	SSLMode  string
}

type RedisConfig struct {
	Host     string
	Port     string
	Password string
	DB       int
}

type JWTConfig struct {
	Secret        string
	RefreshSecret string
	Expiry        time.Duration
	RefreshExpiry time.Duration
}

type S3Config struct {
	Endpoint  string
	Region    string
	Bucket    string
	AccessKey string
	SecretKey string
}

type PaymentConfig struct {
	PayPal struct {
		ClientID string
		Secret   string
		Mode     string
	}
	Stripe struct {
		SecretKey     string
		WebhookSecret string
	}
	BaridiMob struct {
		MerchantID string
		APIKey     string
	}
}

type SMSConfig struct {
	Provider      string
	TwilioSID     string
	TwilioToken   string
	TwilioPhone   string
}

type EmailConfig struct {
	Host     string
	Port     int
	User     string
	Password string
	From     string
}

type RateLimitConfig struct {
	Requests int
	Duration time.Duration
}

type CORSConfig struct {
	Origins []string
}

type BotConfig struct {
	Count            int
	ActivityInterval time.Duration
}

type PointsConfig struct {
	FreeZizoCap    int
	InitialPoints  int
}

func Load() *Config {
	// Load .env file if exists
	_ = godotenv.Load()

	jwtExpiry, _ := time.ParseDuration(getEnv("JWT_EXPIRY", "15m"))
	jwtRefreshExpiry, _ := time.ParseDuration(getEnv("JWT_REFRESH_EXPIRY", "168h"))
	rateLimitDuration, _ := time.ParseDuration(getEnv("RATE_LIMIT_DURATION", "1m"))
	botActivityInterval, _ := time.ParseDuration(getEnv("BOT_ACTIVITY_INTERVAL", "5m"))

	cfg := &Config{
		Server: ServerConfig{
			Port:       getEnv("PORT", "8080"),
			Env:        getEnv("ENV", "development"),
			APIVersion: getEnv("API_VERSION", "v1"),
		},
		Database: DatabaseConfig{
			Host:     getEnv("DB_HOST", "localhost"),
			Port:     getEnv("DB_PORT", "5432"),
			User:     getEnv("DB_USER", "sinf_user"),
			Password: getEnv("DB_PASSWORD", ""),
			DBName:   getEnv("DB_NAME", "sinf_db"),
			SSLMode:  getEnv("DB_SSLMODE", "disable"),
		},
		Redis: RedisConfig{
			Host:     getEnv("REDIS_HOST", "localhost"),
			Port:     getEnv("REDIS_PORT", "6379"),
			Password: getEnv("REDIS_PASSWORD", ""),
			DB:       getEnvAsInt("REDIS_DB", 0),
		},
		JWT: JWTConfig{
			Secret:        getEnv("JWT_SECRET", "change-this-secret"),
			RefreshSecret: getEnv("JWT_REFRESH_SECRET", "change-this-refresh-secret"),
			Expiry:        jwtExpiry,
			RefreshExpiry: jwtRefreshExpiry,
		},
		S3: S3Config{
			Endpoint:  getEnv("S3_ENDPOINT", "https://s3.amazonaws.com"),
			Region:    getEnv("S3_REGION", "us-east-1"),
			Bucket:    getEnv("S3_BUCKET", "sinf-uploads"),
			AccessKey: getEnv("S3_ACCESS_KEY", ""),
			SecretKey: getEnv("S3_SECRET_KEY", ""),
		},
		RateLimit: RateLimitConfig{
			Requests: getEnvAsInt("RATE_LIMIT_REQUESTS", 100),
			Duration: rateLimitDuration,
		},
		Bot: BotConfig{
			Count:            getEnvAsInt("BOT_COUNT", 50),
			ActivityInterval: botActivityInterval,
		},
		Points: PointsConfig{
			FreeZizoCap:   getEnvAsInt("FREE_ZIZO_CAP", 30),
			InitialPoints: getEnvAsInt("INITIAL_POINTS", 30),
		},
	}

	// Payment config
	cfg.Payment.PayPal.ClientID = getEnv("PAYPAL_CLIENT_ID", "")
	cfg.Payment.PayPal.Secret = getEnv("PAYPAL_SECRET", "")
	cfg.Payment.PayPal.Mode = getEnv("PAYPAL_MODE", "sandbox")

	cfg.Payment.Stripe.SecretKey = getEnv("STRIPE_SECRET_KEY", "")
	cfg.Payment.Stripe.WebhookSecret = getEnv("STRIPE_WEBHOOK_SECRET", "")

	cfg.Payment.BaridiMob.MerchantID = getEnv("BARIDIMOB_MERCHANT_ID", "")
	cfg.Payment.BaridiMob.APIKey = getEnv("BARIDIMOB_API_KEY", "")

	// SMS config
	cfg.SMS.Provider = getEnv("SMS_PROVIDER", "twilio")
	cfg.SMS.TwilioSID = getEnv("TWILIO_ACCOUNT_SID", "")
	cfg.SMS.TwilioToken = getEnv("TWILIO_AUTH_TOKEN", "")
	cfg.SMS.TwilioPhone = getEnv("TWILIO_PHONE_NUMBER", "")

	// Email config
	cfg.Email.Host = getEnv("SMTP_HOST", "smtp.gmail.com")
	cfg.Email.Port = getEnvAsInt("SMTP_PORT", 587)
	cfg.Email.User = getEnv("SMTP_USER", "")
	cfg.Email.Password = getEnv("SMTP_PASSWORD", "")
	cfg.Email.From = getEnv("SMTP_FROM", "noreply@sinf.com")

	return cfg
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func getEnvAsInt(key string, defaultValue int) int {
	valueStr := getEnv(key, "")
	if value, err := strconv.Atoi(valueStr); err == nil {
		return value
	}
	return defaultValue
}

func (c *Config) Validate() error {
	if c.Database.Password == "" {
		log.Println("WARNING: DB_PASSWORD is not set")
	}
	if c.JWT.Secret == "change-this-secret" {
		log.Println("WARNING: Using default JWT_SECRET - change this in production!")
	}
	return nil
}
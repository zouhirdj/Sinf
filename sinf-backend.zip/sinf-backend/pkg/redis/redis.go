package redis

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/redis/go-redis/v9"
	"github.com/sinf/backend/config"
)

type Client struct {
	*redis.Client
}

func NewRedis(cfg *config.RedisConfig) (*Client, error) {
	rdb := redis.NewClient(&redis.Options{
		Addr:     fmt.Sprintf("%s:%s", cfg.Host, cfg.Port),
		Password: cfg.Password,
		DB:       cfg.DB,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := rdb.Ping(ctx).Err(); err != nil {
		return nil, fmt.Errorf("failed to connect to Redis: %w", err)
	}

	log.Println("✅ Connected to Redis")

	return &Client{rdb}, nil
}

// Rate limiting
func (c *Client) CheckRateLimit(ctx context.Context, key string, limit int, duration time.Duration) (bool, error) {
	count, err := c.Incr(ctx, key).Result()
	if err != nil {
		return false, err
	}

	if count == 1 {
		c.Expire(ctx, key, duration)
	}

	return count <= int64(limit), nil
}

// Increment counter
func (c *Client) IncrementCounter(ctx context.Context, key string) error {
	return c.Incr(ctx, key).Err()
}

// Decrement counter
func (c *Client) DecrementCounter(ctx context.Context, key string) error {
	return c.Decr(ctx, key).Err()
}

// Get counter
func (c *Client) GetCounter(ctx context.Context, key string) (int64, error) {
	return c.Get(ctx, key).Int64()
}

// Cache operations
func (c *Client) SetCache(ctx context.Context, key string, value interface{}, expiration time.Duration) error {
	return c.Set(ctx, key, value, expiration).Err()
}

func (c *Client) GetCache(ctx context.Context, key string) (string, error) {
	return c.Get(ctx, key).Result()
}

func (c *Client) DeleteCache(ctx context.Context, key string) error {
	return c.Del(ctx, key).Err()
}
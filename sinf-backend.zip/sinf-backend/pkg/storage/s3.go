package storage

import (
    "context"
    "fmt"
    "io"
    "time"

    "github.com/aws/aws-sdk-go-v2/aws"
    "github.com/aws/aws-sdk-go-v2/config"
    "github.com/aws/aws-sdk-go-v2/service/s3"
    "github.com/aws/aws-sdk-go-v2/service/s3/types"
)

type S3Storage struct {
    client     *s3.Client
    bucketName string
    region     string
}

func NewS3Storage(bucketName, region string) (*S3Storage, error) {
    cfg, err := config.LoadDefaultConfig(context.TODO(),
        config.WithRegion(region),
    )
    if err != nil {
        return nil, fmt.Errorf("unable to load SDK config: %w", err)
    }

    client := s3.NewFromConfig(cfg)

    return &S3Storage{
        client:     client,
        bucketName: bucketName,
        region:     region,
    }, nil
}

func (s *S3Storage) UploadFile(ctx context.Context, key string, body io.Reader, contentType string) error {
    _, err := s.client.PutObject(ctx, &s3.PutObjectInput{
        Bucket:      aws.String(s.bucketName),
        Key:         aws.String(key),
        Body:        body,
        ContentType: aws.String(contentType),
        ACL:         types.ObjectCannedACLPrivate,
    })

    if err != nil {
        return fmt.Errorf("failed to upload file: %w", err)
    }

    return nil
}

func (s *S3Storage) GeneratePresignedURL(ctx context.Context, key string, expiration time.Duration) (string, error) {
    presignClient := s3.NewPresignClient(s.client)

    presignedURL, err := presignClient.PresignGetObject(ctx, &s3.GetObjectInput{
        Bucket: aws.String(s.bucketName),
        Key:    aws.String(key),
    }, func(opts *s3.PresignOptions) {
        opts.Expires = expiration
    })

    if err != nil {
        return "", fmt.Errorf("failed to generate presigned URL: %w", err)
    }

    return presignedURL.URL, nil
}

func (s *S3Storage) GeneratePresignedUploadURL(ctx context.Context, key string, expiration time.Duration) (string, error) {
    presignClient := s3.NewPresignClient(s.client)

    presignedURL, err := presignClient.PresignPutObject(ctx, &s3.PutObjectInput{
        Bucket: aws.String(s.bucketName),
        Key:    aws.String(key),
    }, func(opts *s3.PresignOptions) {
        opts.Expires = expiration
    })

    if err != nil {
        return "", fmt.Errorf("failed to generate presigned upload URL: %w", err)
    }

    return presignedURL.URL, nil
}

func (s *S3Storage) DeleteFile(ctx context.Context, key string) error {
    _, err := s.client.DeleteObject(ctx, &s3.DeleteObjectInput{
        Bucket: aws.String(s.bucketName),
        Key:    aws.String(key),
    })

    if err != nil {
        return fmt.Errorf("failed to delete file: %w", err)
    }

    return nil
}

func (s *S3Storage) GetFileMetadata(ctx context.Context, key string) (*s3.HeadObjectOutput, error) {
    result, err := s.client.HeadObject(ctx, &s3.HeadObjectInput{
        Bucket: aws.String(s.bucketName),
        Key:    aws.String(key),
    })

    if err != nil {
        return nil, fmt.Errorf("failed to get file metadata: %w", err)
    }

    return result, nil
}
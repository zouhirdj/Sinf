package websocket

import (
    "encoding/json"
    "log"
    "sync"
)

type Message struct {
    Type      string                 `json:"type"`
    ChatID    string                 `json:"chat_id,omitempty"`
    UserID    string                 `json:"user_id,omitempty"`
    Content   string                 `json:"content,omitempty"`
    Data      map[string]interface{} `json:"data,omitempty"`
    Timestamp int64                  `json:"timestamp"`
}

type Hub struct {
    clients    map[string]map[*Client]bool // userID -> clients
    broadcast  chan *Message
    register   chan *Client
    unregister chan *Client
    mu         sync.RWMutex
}

func NewHub() *Hub {
    return &Hub{
        clients:    make(map[string]map[*Client]bool),
        broadcast:  make(chan *Message, 256),
        register:   make(chan *Client),
        unregister: make(chan *Client),
    }
}

func (h *Hub) Run() {
    for {
        select {
        case client := <-h.register:
            h.mu.Lock()
            if h.clients[client.userID] == nil {
                h.clients[client.userID] = make(map[*Client]bool)
            }
            h.clients[client.userID][client] = true
            h.mu.Unlock()
            log.Printf("Client registered: user=%s", client.userID)

        case client := <-h.unregister:
            h.mu.Lock()
            if clients, ok := h.clients[client.userID]; ok {
                if _, exists := clients[client]; exists {
                    delete(clients, client)
                    close(client.send)
                    if len(clients) == 0 {
                        delete(h.clients, client.userID)
                    }
                }
            }
            h.mu.Unlock()
            log.Printf("Client unregistered: user=%s", client.userID)

        case message := <-h.broadcast:
            h.mu.RLock()
            // Send to specific user if UserID is set
            if message.UserID != "" {
                if clients, ok := h.clients[message.UserID]; ok {
                    data, _ := json.Marshal(message)
                    for client := range clients {
                        select {
                        case client.send <- data:
                        default:
                            close(client.send)
                            delete(clients, client)
                        }
                    }
                }
            } else {
                // Broadcast to all
                data, _ := json.Marshal(message)
                for _, clients := range h.clients {
                    for client := range clients {
                        select {
                        case client.send <- data:
                        default:
                            close(client.send)
                            delete(clients, client)
                        }
                    }
                }
            }
            h.mu.RUnlock()
        }
    }
}

func (h *Hub) SendToUser(userID string, message *Message) {
    h.broadcast <- message
}

func (h *Hub) BroadcastMessage(message *Message) {
    h.broadcast <- message
}
package auth

import (
    "context"
    "database/sql"
    "errors"
    "fmt"
    "math/rand"
    "time"

    "github.com/google/uuid"
    "golang.org/x/crypto/bcrypt"
)

var (
    ErrInvalidCredentials = errors.New("invalid credentials")
    ErrUserNotFound       = errors.New("user not found")
    ErrUserExists         = errors.New("user already exists")
    ErrInvalidOTP         = errors.New("invalid or expired OTP")
)

type Service struct {
    db *sql.DB
}

func NewService(db *sql.DB) *Service {
    return &Service{db: db}
}

type RegisterRequest struct {
    Name     string `json:"name"`
    Email    string `json:"email"`
    Phone    string `json:"phone"`
    Password string `json:"password"`
}

type User struct {
    ID        string
    Name      string
    Email     string
    Phone     string
    Role      string
    Verified  bool
    CreatedAt time.Time
}

func (s *Service) Register(ctx context.Context, req RegisterRequest) (string, error) {
    // Check if user exists
    var exists bool
    err := s.db.QueryRowContext(ctx,
        "SELECT EXISTS(SELECT 1 FROM users WHERE email = $1 OR phone = $2)",
        req.Email, req.Phone).Scan(&exists)
    if err != nil {
        return "", err
    }
    if exists {
        return "", ErrUserExists
    }

    // Hash password
    hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
    if err != nil {
        return "", err
    }

    // Generate OTP
    otp := fmt.Sprintf("%06d", rand.Intn(1000000))
    otpExpiry := time.Now().Add(10 * time.Minute)

    // Create user
    userID := uuid.New().String()
    _, err = s.db.ExecContext(ctx, `
        INSERT INTO users (id, name, email, phone, password_hash, role, verified, otp, otp_expiry, zizo_balance, created_at)
        VALUES ($1, $2, $3, $4, $5, 'user', false, $6, $7, 10, NOW())
    `, userID, req.Name, req.Email, req.Phone, string(hashedPassword), otp, otpExpiry)

    if err != nil {
        return "", err
    }

    // TODO: Send OTP via email/SMS
    // For now, log it
    fmt.Printf("OTP for user %s: %s\n", req.Email, otp)

    return userID, nil
}

func (s *Service) VerifyOTP(ctx context.Context, userID, otp string) error {
    var storedOTP string
    var otpExpiry time.Time

    err := s.db.QueryRowContext(ctx,
        "SELECT otp, otp_expiry FROM users WHERE id = $1",
        userID).Scan(&storedOTP, &otpExpiry)

    if err != nil {
        if err == sql.ErrNoRows {
            return ErrUserNotFound
        }
        return err
    }

    if storedOTP != otp || time.Now().After(otpExpiry) {
        return ErrInvalidOTP
    }

    // Mark as verified
    _, err = s.db.ExecContext(ctx,
        "UPDATE users SET verified = true, otp = NULL, otp_expiry = NULL WHERE id = $1",
        userID)

    return err
}

func (s *Service) Login(ctx context.Context, emailOrPhone, password string) (*User, error) {
    var user User
    var passwordHash string

    err := s.db.QueryRowContext(ctx, `
        SELECT id, name, email, phone, password_hash, role, verified, created_at
        FROM users
        WHERE (email = $1 OR phone = $1) AND verified = true
    `, emailOrPhone).Scan(&user.ID, &user.Name, &user.Email, &user.Phone,
        &passwordHash, &user.Role, &user.Verified, &user.CreatedAt)

    if err != nil {
        if err == sql.ErrNoRows {
            return nil, ErrInvalidCredentials
        }
        return nil, err
    }

    // Verify password
    if err := bcrypt.CompareHashAndPassword([]byte(passwordHash), []byte(password)); err != nil {
        return nil, ErrInvalidCredentials
    }

    return &user, nil
}

func (s *Service) ForgotPassword(ctx context.Context, emailOrPhone string) (string, error) {
    var userID string
    err := s.db.QueryRowContext(ctx,
        "SELECT id FROM users WHERE email = $1 OR phone = $1",
        emailOrPhone).Scan(&userID)

    if err != nil {
        if err == sql.ErrNoRows {
            return "", ErrUserNotFound
        }
        return "", err
    }

    // Generate OTP
    otp := fmt.Sprintf("%06d", rand.Intn(1000000))
    otpExpiry := time.Now().Add(10 * time.Minute)

    _, err = s.db.ExecContext(ctx,
        "UPDATE users SET otp = $1, otp_expiry = $2 WHERE id = $3",
        otp, otpExpiry, userID)

    if err != nil {
        return "", err
    }

    // TODO: Send OTP
    fmt.Printf("Password reset OTP for user %s: %s\n", emailOrPhone, otp)

    return userID, nil
}

func (s *Service) ResetPassword(ctx context.Context, userID, otp, newPassword string) error {
    var storedOTP string
    var otpExpiry time.Time

    err := s.db.QueryRowContext(ctx,
        "SELECT otp, otp_expiry FROM users WHERE id = $1",
        userID).Scan(&storedOTP, &otpExpiry)

    if err != nil {
        return err
    }

    if storedOTP != otp || time.Now().After(otpExpiry) {
        return ErrInvalidOTP
    }

    // Hash new password
    hashedPassword, err := bcrypt.GenerateFromPassword([]byte(newPassword), bcrypt.DefaultCost)
    if err != nil {
        return err
    }

    _, err = s.db.ExecContext(ctx,
        "UPDATE users SET password_hash = $1, otp = NULL, otp_expiry = NULL WHERE id = $2",
        string(hashedPassword), userID)

    return err
}
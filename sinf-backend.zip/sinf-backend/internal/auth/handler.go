package auth

import (
    "encoding/json"
    "net/http"
    "sinf-backend/pkg/jwt"
)

type Handler struct {
    service    *Service
    jwtManager *jwt.Manager
}

func NewHandler(service *Service, jwtManager *jwt.Manager) *Handler {
    return &Handler{
        service:    service,
        jwtManager: jwtManager,
    }
}

func (h *Handler) Register(w http.ResponseWriter, r *http.Request) {
    var req RegisterRequest
    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "Invalid request", http.StatusBadRequest)
        return
    }

    userID, err := h.service.Register(r.Context(), req)
    if err != nil {
        if err == ErrUserExists {
            http.Error(w, "User already exists", http.StatusConflict)
            return
        }
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(map[string]interface{}{
        "status": "success",
        "data": map[string]string{
            "user_id": userID,
            "message": "Verify OTP sent",
        },
    })
}

func (h *Handler) VerifyOTP(w http.ResponseWriter, r *http.Request) {
    var req struct {
        UserID string `json:"user_id"`
        OTP    string `json:"otp"`
    }

    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "Invalid request", http.StatusBadRequest)
        return
    }

    if err := h.service.VerifyOTP(r.Context(), req.UserID, req.OTP); err != nil {
        if err == ErrInvalidOTP {
            http.Error(w, "Invalid or expired OTP", http.StatusBadRequest)
            return
        }
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    // Generate tokens
    token, _ := h.jwtManager.GenerateAccessToken(req.UserID, "", "user")
    refreshToken, _ := h.jwtManager.GenerateRefreshToken(req.UserID)

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(map[string]interface{}{
        "status": "success",
        "data": map[string]string{
            "token":         token,
            "refresh_token": refreshToken,
        },
    })
}

func (h *Handler) Login(w http.ResponseWriter, r *http.Request) {
    var req struct {
        EmailOrPhone string `json:"email_or_phone"`
        Password     string `json:"password"`
    }

    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "Invalid request", http.StatusBadRequest)
        return
    }

    user, err := h.service.Login(r.Context(), req.EmailOrPhone, req.Password)
    if err != nil {
        if err == ErrInvalidCredentials {
            http.Error(w, "Invalid credentials", http.StatusUnauthorized)
            return
        }
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    // Generate tokens
    token, _ := h.jwtManager.GenerateAccessToken(user.ID, user.Email, user.Role)
    refreshToken, _ := h.jwtManager.GenerateRefreshToken(user.ID)

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(map[string]interface{}{
        "status": "success",
        "data": map[string]interface{}{
            "token":         token,
            "refresh_token": refreshToken,
            "user_id":       user.ID,
        },
    })
}

func (h *Handler) ForgotPassword(w http.ResponseWriter, r *http.Request) {
    var req struct {
        EmailOrPhone string `json:"email_or_phone"`
    }

    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "Invalid request", http.StatusBadRequest)
        return
    }

    userID, err := h.service.ForgotPassword(r.Context(), req.EmailOrPhone)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(map[string]interface{}{
        "status": "success",
        "data": map[string]interface{}{
            "message": "Password reset OTP sent",
            "user_id": userID,
        },
    })
}

func (h *Handler) ResetPassword(w http.ResponseWriter, r *http.Request) {
    var req struct {
        UserID      string `json:"user_id"`
        OTP         string `json:"otp"`
        NewPassword string `json:"new_password"`
    }

    if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
        http.Error(w, "Invalid request", http.StatusBadRequest)
        return
    }

    if err := h.service.ResetPassword(r.Context(), req.UserID, req.OTP, req.NewPassword); err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(map[string]interface{}{
        "status": "success",
        "data": map[string]string{
            "message": "Password reset successful",
        },
    })
}
package main

import (
    "context"
    "log"
    "net/http"
    "os"
    "os/signal"
    "syscall"
    "time"

    "sinf-backend/config"
    "sinf-backend/internal/auth"
    "sinf-backend/pkg/database"
    "sinf-backend/pkg/jwt"
    "sinf-backend/pkg/redis"
    "sinf-backend/pkg/websocket"

    "github.com/gorilla/mux"
    "github.com/rs/cors"
)

func main() {
    // Load configuration
    cfg := config.Load()

    // Initialize database
    db, err := database.NewPostgresDB(cfg.DatabaseURL)
    if err != nil {
        log.Fatalf("Failed to connect to database: %v", err)
    }
    defer db.Close()

    // Initialize Redis
    redisClient := redis.NewRedisClient(cfg.RedisURL)
    defer redisClient.Close()

    // Initialize JWT manager
    jwtManager := jwt.NewManager(
        cfg.JWTSecret,
        15*time.Minute,  // Access token duration
        7*24*time.Hour,  // Refresh token duration
    )

    // Initialize WebSocket hub
    wsHub := websocket.NewHub()
    go wsHub.Run()

    // Initialize services
    authService := auth.NewService(db)

    // Initialize handlers
    authHandler := auth.NewHandler(authService, jwtManager)

    // Setup router
    router := mux.NewRouter()

    // API v1 routes
    apiV1 := router.PathPrefix("/api/v1").Subrouter()

    // Auth routes
    apiV1.HandleFunc("/auth/register", authHandler.Register).Methods("POST")
    apiV1.HandleFunc("/auth/verify-otp", authHandler.VerifyOTP).Methods("POST")
    apiV1.HandleFunc("/auth/login", authHandler.Login).Methods("POST")
    apiV1.HandleFunc("/auth/forgot-password", authHandler.ForgotPassword).Methods("POST")
    apiV1.HandleFunc("/auth/reset-password", authHandler.ResetPassword).Methods("POST")

    // Health check
    router.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
        w.WriteHeader(http.StatusOK)
        w.Write([]byte("OK"))
    }).Methods("GET")

    // CORS configuration
    c := cors.New(cors.Options{
        AllowedOrigins:   []string{"*"},
        AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
        AllowedHeaders:   []string{"*"},
        AllowCredentials: true,
    })

    handler := c.Handler(router)

    // Create server
    srv := &http.Server{
        Addr:         ":" + cfg.Port,
        Handler:      handler,
        ReadTimeout:  15 * time.Second,
        WriteTimeout: 15 * time.Second,
        IdleTimeout:  60 * time.Second,
    }

    // Start server in goroutine
    go func() {
        log.Printf("Server starting on port %s", cfg.Port)
        if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
            log.Fatalf("Server failed to start: %v", err)
        }
    }()

    // Graceful shutdown
    quit := make(chan os.Signal, 1)
    signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
    <-quit

    log.Println("Server shutting down...")

    ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
    defer cancel()

    if err := srv.Shutdown(ctx); err != nil {
        log.Fatalf("Server forced to shutdown: %v", err)
    }

    log.Println("Server exited")
}
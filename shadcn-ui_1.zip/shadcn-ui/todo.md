# صِنف (Sinf) Social Platform - MVP Development Plan

## Design Guidelines

### Design References
- **Primary Inspiration**: Facebook-like simplicity with modern green theme
- **Style**: Clean, minimal, RTL-ready Arabic interface
- **Focus**: Content-first, easy navigation, comfortable for extended use

### Color Palette
- **Primary Green**: #4CD964 (Main brand color - buttons, headers, links)
- **Dark Gray**: #2E2E2E (Text, borders)
- **Medium Gray**: #9A9A9A (Secondary text)
- **Light Gray**: #F6F7F8 (Backgrounds, cards)
- **Zizo Yellow**: #FFC400 (Points system only)
- **White**: #FFFFFF (Cards, backgrounds)

### Typography
- **Font Family**: 
  - Arabic: Cairo or Tajawal
  - English: Poppins
- **Sizes**:
  - Headings: 17-18px (font-weight: 600)
  - Body: 14-15px (font-weight: 400)
  - Comments: 13px
  - Buttons: 14-15px (font-weight: 500)

### Component Styles
- **Buttons**: 
  - Primary: Green background (#4CD964), white text, rounded-lg (10px)
  - Secondary: White background, green border, green text
  - Height: 42px
- **Cards**: 
  - Background: White
  - Border: 1px solid #E5E7EB
  - Border radius: 12px
  - Shadow: subtle (shadow-sm)
- **Inputs**:
  - Border: 1px solid #D1D5DB
  - Focus: Green ring (#4CD964)
  - Rounded: 8px

### Layout & Spacing
- **Section padding**: 20-24px
- **Card spacing**: 12px between posts
- **Element spacing**: 8-10px internal padding
- **Max width**: 1200px (centered)

### Images to Generate
1. **hero-banner.jpg** - Platform hero image with green theme (Style: modern, clean)
2. **logo-sinf.png** - Green square logo with white "S" letter (Style: minimal, rounded corners)
3. **logo-zizo.png** - Yellow circle with white "Z" letter (Style: simple, bold)
4. **default-avatar.png** - Default user avatar (Style: neutral, professional)
5. **empty-state.png** - Empty feed illustration (Style: friendly, green accent)

---

## Development Tasks

### Phase 1: Setup & Core Structure
1. ✅ Initialize shadcn-ui template
2. ✅ Install dependencies
3. Generate brand images
4. Update index.html with proper Arabic meta tags
5. Create basic routing structure

### Phase 2: Authentication System
6. Create login page with email/phone + password
7. Create registration page with OTP verification UI
8. Create password recovery flow
9. Implement Supabase auth integration
10. Add protected route wrapper

### Phase 3: Main Layout & Navigation
11. Create main app layout with header
12. Build navigation bar (Home, Profile, Store, Notifications)
13. Create sidebar for quick actions
14. Implement responsive mobile menu

### Phase 4: Social Feed
15. Create post card component
16. Build post creation modal (text, images)
17. Implement like/comment functionality
18. Create comment section UI
19. Add post types (wisdom, story, service)

### Phase 5: Zizo Points System
20. Create points display component
21. Build recharge code input interface
22. Create recharge cards display (50Z, 100Z, 200Z)
23. Implement payment method selection modal
24. Add points history view

### Phase 6: User Profile
25. Create profile page layout
26. Build profile edit form
27. Display user's posts
28. Show points balance
29. Add cognitive profile display

### Phase 7: Database Integration
30. Setup Supabase tables (users, posts, likes, comments)
31. Create recharge_cards table with codes
32. Implement points transaction system
33. Add real-time subscriptions for feed

### Phase 8: Polish & Testing
34. Add loading states
35. Implement error handling
36. Add Arabic RTL support
37. Test responsive design
38. Optimize performance
39. Run lint and build checks

---

## File Structure

```
src/
├── components/
│   ├── auth/
│   │   ├── LoginForm.tsx
│   │   ├── RegisterForm.tsx
│   │   └── OTPVerification.tsx
│   ├── layout/
│   │   ├── Header.tsx
│   │   ├── Sidebar.tsx
│   │   └── MainLayout.tsx
│   ├── feed/
│   │   ├── PostCard.tsx
│   │   ├── CreatePost.tsx
│   │   ├── CommentSection.tsx
│   │   └── FeedList.tsx
│   ├── points/
│   │   ├── PointsDisplay.tsx
│   │   ├── RechargeInput.tsx
│   │   ├── RechargeCards.tsx
│   │   └── PaymentModal.tsx
│   ├── profile/
│   │   ├── ProfileHeader.tsx
│   │   ├── ProfileEdit.tsx
│   │   └── UserPosts.tsx
│   └── ui/ (shadcn components)
├── pages/
│   ├── Index.tsx (Landing/Login)
│   ├── Register.tsx
│   ├── Feed.tsx
│   ├── Profile.tsx
│   └── Store.tsx
├── lib/
│   ├── supabase.ts
│   ├── auth.ts
│   └── utils.ts
└── types/
    └── index.ts
```

---

## Database Schema (Supabase)

### Tables to Create:

1. **app_fcb82_users** (extends auth.users)
   - user_id (uuid, FK to auth.users)
   - name (text)
   - phone (text)
   - cognitive_profile_id (int)
   - points_balance (int, default: 30)
   - zizo_balance (int, default: 0)
   - real_user (boolean, default: true)
   - bot (boolean, default: false)
   - created_at (timestamp)

2. **app_fcb82_posts**
   - post_id (uuid, PK)
   - author_id (uuid, FK)
   - type (text: wisdom/story/service)
   - content (text)
   - media_urls (jsonb)
   - likes_count (int, default: 0)
   - comments_count (int, default: 0)
   - created_at (timestamp)

3. **app_fcb82_likes**
   - like_id (uuid, PK)
   - post_id (uuid, FK)
   - user_id (uuid, FK)
   - created_at (timestamp)
   - UNIQUE(post_id, user_id)

4. **app_fcb82_comments**
   - comment_id (uuid, PK)
   - post_id (uuid, FK)
   - user_id (uuid, FK)
   - content (text)
   - created_at (timestamp)

5. **app_fcb82_recharge_cards**
   - id (uuid, PK)
   - code (text, UNIQUE)
   - points (int: 50/100/200)
   - used (boolean, default: false)
   - used_by (uuid, nullable)
   - used_at (timestamp, nullable)
   - created_at (timestamp)

6. **app_fcb82_points_history**
   - id (uuid, PK)
   - user_id (uuid, FK)
   - amount (int)
   - type (text: earned/spent/recharged)
   - description (text)
   - created_at (timestamp)

---

## MVP Scope (Simplified Demo)

### Included Features:
✅ User authentication (login/register)
✅ Social feed with posts
✅ Like and comment functionality
✅ Points display system
✅ Recharge code input
✅ Basic profile page
✅ Green-themed UI matching brand identity
✅ RTL Arabic support

### Excluded from MVP (Future):
❌ Payment gateway integration (PayPal/Stripe/BaridiMob)
❌ Bot accounts system (600 bots)
❌ Marketplace/Store functionality
❌ Real-time chat system
❌ Advanced admin panel
❌ Email/SMS notifications
❌ File upload to S3

---

## Notes
- Focus on core social features and points display
- Use Supabase for all backend operations
- Implement proper RLS policies for security
- Keep UI clean and Facebook-like
- Ensure RTL support for Arabic text
- Pre-populate recharge_cards table with provided codes
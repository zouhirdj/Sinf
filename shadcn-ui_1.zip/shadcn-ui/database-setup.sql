-- =====================================================
-- صِنف (Sinf) Platform - Database Setup Script
-- =====================================================
-- Run this SQL in your Supabase SQL Editor after connecting your project
-- This will create all necessary tables, RLS policies, and functions

BEGIN;

-- =====================================================
-- 1. USERS TABLE (extends auth.users)
-- =====================================================
CREATE TABLE IF NOT EXISTS app_fcb82_users (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    cognitive_profile_id INTEGER DEFAULT 1,
    points_balance INTEGER DEFAULT 30,
    zizo_balance INTEGER DEFAULT 0,
    real_user BOOLEAN DEFAULT true,
    bot BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- RLS Policies for users
ALTER TABLE app_fcb82_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles" ON app_fcb82_users
    FOR SELECT USING (true);

CREATE POLICY "Users can update own profile" ON app_fcb82_users
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile" ON app_fcb82_users
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- =====================================================
-- 2. POSTS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS app_fcb82_posts (
    post_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    author_id UUID REFERENCES app_fcb82_users(user_id) ON DELETE CASCADE NOT NULL,
    type TEXT CHECK (type IN ('wisdom', 'story', 'service')) NOT NULL,
    content TEXT NOT NULL,
    media_urls JSONB DEFAULT '[]'::jsonb,
    likes_count INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS posts_author_idx ON app_fcb82_posts(author_id);
CREATE INDEX IF NOT EXISTS posts_created_idx ON app_fcb82_posts(created_at DESC);
CREATE INDEX IF NOT EXISTS posts_type_idx ON app_fcb82_posts(type);

-- RLS Policies for posts
ALTER TABLE app_fcb82_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view posts" ON app_fcb82_posts
    FOR SELECT USING (true);

CREATE POLICY "Authenticated users can create posts" ON app_fcb82_posts
    FOR INSERT TO authenticated WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can delete own posts" ON app_fcb82_posts
    FOR DELETE USING (auth.uid() = author_id);

-- =====================================================
-- 3. LIKES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS app_fcb82_likes (
    like_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id UUID REFERENCES app_fcb82_posts(post_id) ON DELETE CASCADE NOT NULL,
    user_id UUID REFERENCES app_fcb82_users(user_id) ON DELETE CASCADE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(post_id, user_id)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS likes_post_idx ON app_fcb82_likes(post_id);
CREATE INDEX IF NOT EXISTS likes_user_idx ON app_fcb82_likes(user_id);

-- RLS Policies for likes
ALTER TABLE app_fcb82_likes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view likes" ON app_fcb82_likes
    FOR SELECT USING (true);

CREATE POLICY "Authenticated users can like" ON app_fcb82_likes
    FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unlike" ON app_fcb82_likes
    FOR DELETE USING (auth.uid() = user_id);

-- =====================================================
-- 4. COMMENTS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS app_fcb82_comments (
    comment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id UUID REFERENCES app_fcb82_posts(post_id) ON DELETE CASCADE NOT NULL,
    user_id UUID REFERENCES app_fcb82_users(user_id) ON DELETE CASCADE NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS comments_post_idx ON app_fcb82_comments(post_id);
CREATE INDEX IF NOT EXISTS comments_user_idx ON app_fcb82_comments(user_id);
CREATE INDEX IF NOT EXISTS comments_created_idx ON app_fcb82_comments(created_at);

-- RLS Policies for comments
ALTER TABLE app_fcb82_comments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view comments" ON app_fcb82_comments
    FOR SELECT USING (true);

CREATE POLICY "Authenticated users can comment" ON app_fcb82_comments
    FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own comments" ON app_fcb82_comments
    FOR DELETE USING (auth.uid() = user_id);

-- =====================================================
-- 5. RECHARGE CARDS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS app_fcb82_recharge_cards (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT UNIQUE NOT NULL,
    points INTEGER CHECK (points IN (50, 100, 200)) NOT NULL,
    used BOOLEAN DEFAULT false,
    used_by UUID REFERENCES app_fcb82_users(user_id) ON DELETE SET NULL,
    used_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for code lookup
CREATE INDEX IF NOT EXISTS recharge_cards_code_idx ON app_fcb82_recharge_cards(code);
CREATE INDEX IF NOT EXISTS recharge_cards_used_idx ON app_fcb82_recharge_cards(used);

-- RLS Policies for recharge cards
ALTER TABLE app_fcb82_recharge_cards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view unused cards" ON app_fcb82_recharge_cards
    FOR SELECT TO authenticated USING (NOT used);

CREATE POLICY "Authenticated users can redeem cards" ON app_fcb82_recharge_cards
    FOR UPDATE TO authenticated USING (NOT used);

-- =====================================================
-- 6. POINTS HISTORY TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS app_fcb82_points_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES app_fcb82_users(user_id) ON DELETE CASCADE NOT NULL,
    amount INTEGER NOT NULL,
    type TEXT CHECK (type IN ('earned', 'spent', 'recharged')) NOT NULL,
    description TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS points_history_user_idx ON app_fcb82_points_history(user_id);
CREATE INDEX IF NOT EXISTS points_history_created_idx ON app_fcb82_points_history(created_at DESC);

-- RLS Policies for points history
ALTER TABLE app_fcb82_points_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own history" ON app_fcb82_points_history
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "System can insert history" ON app_fcb82_points_history
    FOR INSERT TO authenticated WITH CHECK (true);

-- =====================================================
-- 7. DATABASE FUNCTIONS
-- =====================================================

-- Function to increment likes count
CREATE OR REPLACE FUNCTION increment_likes(post_id UUID)
RETURNS void AS $$
BEGIN
    UPDATE app_fcb82_posts
    SET likes_count = likes_count + 1
    WHERE app_fcb82_posts.post_id = increment_likes.post_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to decrement likes count
CREATE OR REPLACE FUNCTION decrement_likes(post_id UUID)
RETURNS void AS $$
BEGIN
    UPDATE app_fcb82_posts
    SET likes_count = GREATEST(0, likes_count - 1)
    WHERE app_fcb82_posts.post_id = decrement_likes.post_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to increment comments count
CREATE OR REPLACE FUNCTION increment_comments(post_id UUID)
RETURNS void AS $$
BEGIN
    UPDATE app_fcb82_posts
    SET comments_count = comments_count + 1
    WHERE app_fcb82_posts.post_id = increment_comments.post_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to decrement comments count
CREATE OR REPLACE FUNCTION decrement_comments(post_id UUID)
RETURNS void AS $$
BEGIN
    UPDATE app_fcb82_posts
    SET comments_count = GREATEST(0, comments_count - 1)
    WHERE app_fcb82_posts.post_id = decrement_comments.post_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMIT;

-- =====================================================
-- 8. SAMPLE DATA (Optional - for testing)
-- =====================================================
-- Uncomment the following to insert sample recharge cards

/*
INSERT INTO app_fcb82_recharge_cards (code, points) VALUES
    ('z50-TEST-001', 50),
    ('z100-TEST-001', 100),
    ('z200-TEST-001', 200);
*/

-- =====================================================
-- Setup Complete!
-- =====================================================
-- Next steps:
-- 1. Go to Supabase Dashboard > Authentication > Providers
-- 2. Enable Email provider
-- 3. Configure email templates (optional)
-- 4. Update your .env file with Supabase credentials
export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar: string;
  bio: string;
  cognitiveProfile: string;
  zizoBalance: number;
  role: 'user' | 'admin' | 'bot';
  isBot: boolean;
  createdAt: string;
}

export interface Post {
  id: string;
  authorId: string;
  author: User;
  type: 'wisdom' | 'story' | 'service';
  title: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  likedBy: string[];
  createdAt: string;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  author: User;
  content: string;
  createdAt: string;
}

export interface Chat {
  id: string;
  participants: User[];
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  content: string;
  createdAt: string;
}

export interface Product {
  id: string;
  sellerId: string;
  seller: User;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  downloads: number;
  rating: number;
  createdAt: string;
}

export interface RechargeCard {
  code: string;
  amount: number;
  used: boolean;
}

export interface CognitiveProfile {
  id: string;
  name: string;
  nameAr: string;
  description: string;
  weights: {
    wisdom: number;
    story: number;
    service: number;
  };
}
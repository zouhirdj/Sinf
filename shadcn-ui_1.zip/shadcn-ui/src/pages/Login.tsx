import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Coins } from 'lucide-react';

export const Login: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (isLogin) {
      const success = await login(email, password);
      if (success) {
        navigate('/');
      } else {
        setError('البريد الإلكتروني أو كلمة المرور غير صحيحة');
      }
    } else {
      if (!name.trim() || !phone.trim()) {
        setError('يرجى ملء جميع الحقول');
        return;
      }
      
      const userId = await register(name, email, phone, password);
      if (userId) {
        // Redirect to category quiz
        navigate('/category-quiz', { state: { userId } });
      } else {
        setError('المستخدم موجود بالفعل');
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#4CD964]/10 to-[#FFC400]/10 flex items-center justify-center p-4" dir="rtl">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-[#4CD964] rounded-2xl flex items-center justify-center">
              <span className="text-white font-bold text-3xl">S</span>
            </div>
          </div>
          <CardTitle className="text-2xl">مرحباً بك في صِنف</CardTitle>
          <CardDescription>
            {isLogin ? 'سجل دخولك للمتابعة' : 'أنشئ حساباً جديداً'}
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <div>
                  <Input
                    placeholder="الاسم الكامل"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Input
                    placeholder="رقم الهاتف"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                  />
                </div>
              </>
            )}
            
            <div>
              <Input
                type="email"
                placeholder="البريد الإلكتروني"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            
            <div>
              <Input
                type="password"
                placeholder="كلمة المرور"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-800 rounded-lg p-3 text-sm">
                {error}
              </div>
            )}
            
            {!isLogin && (
              <div className="bg-[#FFC400]/10 border border-[#FFC400]/30 rounded-lg p-3 flex items-center gap-2">
                <Coins className="w-5 h-5 text-[#FFC400]" />
                <span className="text-sm">ستحصل على 30 نقطة مجانية بعد إكمال التصنيف!</span>
              </div>
            )}
            
            <Button
              type="submit"
              className="w-full bg-[#4CD964] hover:bg-[#4CD964]/90"
            >
              {isLogin ? 'تسجيل الدخول' : 'التالي'}
            </Button>
            
            <div className="text-center">
              <button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setError('');
                }}
                className="text-sm text-[#4CD964] hover:underline"
              >
                {isLogin ? 'ليس لديك حساب؟ سجل الآن' : 'لديك حساب؟ سجل دخولك'}
              </button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
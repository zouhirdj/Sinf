import { useState, useEffect } from 'react';
import { db } from '@/lib/supabase';
import { useAuthStore } from '@/lib/auth-store';
import type { Post } from '@/types';
import CreatePost from '@/components/feed/CreatePost';
import PostCard from '@/components/feed/PostCard';
import { Loader2 } from 'lucide-react';

export default function Feed() {
  const user = useAuthStore((state) => state.user);
  const [posts, setPosts] = useState<Post[]>([]);
  const [userLikes, setUserLikes] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFeed();
  }, []);

  const loadFeed = async () => {
    setLoading(true);
    try {
      const [postsData, likesData] = await Promise.all([
        db.getPosts(20, 0),
        user ? db.getUserLikes(user.user_id) : Promise.resolve([])
      ]);
      setPosts(postsData);
      setUserLikes(likesData);
    } catch (error) {
      console.error('Failed to load feed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLikeToggle = async (postId: string) => {
    if (!user) return;

    try {
      const isLiked = await db.toggleLike(postId, user.user_id);
      
      // Update local state
      setPosts(posts.map(post => 
        post.post_id === postId 
          ? { ...post, likes_count: post.likes_count + (isLiked ? 1 : -1) }
          : post
      ));

      if (isLiked) {
        setUserLikes([...userLikes, postId]);
      } else {
        setUserLikes(userLikes.filter(id => id !== postId));
      }
    } catch (error) {
      console.error('Failed to toggle like:', error);
    }
  };

  const handlePostDeleted = (postId: string) => {
    setPosts(posts.filter(post => post.post_id !== postId));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-[#4CD964]" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <CreatePost onPostCreated={loadFeed} />
      
      <div className="space-y-4">
        {posts.length === 0 ? (
          <div className="text-center py-12">
            <img 
              src="/assets/empty-state.png" 
              alt="لا توجد منشورات" 
              className="w-48 h-48 mx-auto mb-4 opacity-50"
            />
            <p className="text-muted-foreground">لا توجد منشورات بعد</p>
            <p className="text-sm text-muted-foreground">كن أول من ينشر!</p>
          </div>
        ) : (
          posts.map((post) => (
            <PostCard
              key={post.post_id}
              post={post}
              userLikes={userLikes}
              onLikeToggle={handleLikeToggle}
              onDelete={handlePostDeleted}
            />
          ))
        )}
      </div>
    </div>
  );
}
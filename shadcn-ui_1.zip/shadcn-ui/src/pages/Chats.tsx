import React from 'react';
import { Layout } from '@/components/Layout';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { MessageCircle } from 'lucide-react';

export const Chats: React.FC = () => {
  const { user } = useAuth();

  if (!user) return null;

  return (
    <Layout>
      <div className="max-w-2xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">المحادثات</h1>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-12 text-gray-500">
              <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>لا توجد محادثات بعد</p>
              <p className="text-sm mt-2">
                عند التعليق على منشور، سيتم فتح محادثة خاصة مع صاحب المنشور
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};
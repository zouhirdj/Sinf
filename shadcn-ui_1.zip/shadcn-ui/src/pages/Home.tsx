import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/Layout';
import { useAuth } from '@/contexts/AuthContext';
import { getPosts, savePost, Post } from '@/lib/storage';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Home: React.FC = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = ['all', 'wisdom', 'story', 'service'];

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = () => {
    const allPosts = getPosts();
    setPosts(allPosts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
  };

  const handleLike = (postId: string) => {
    if (!user) return;

    const allPosts = getPosts();
    const post = allPosts.find(p => p.id === postId);
    
    if (post) {
      const hasLiked = post.likedBy.includes(user.id);
      
      if (hasLiked) {
        post.likedBy = post.likedBy.filter(id => id !== user.id);
        post.likes--;
      } else {
        post.likedBy.push(user.id);
        post.likes++;
      }
      
      savePost(post);
      loadPosts();
    }
  };

  const filteredPosts = selectedCategory === 'all' 
    ? posts 
    : posts.filter(p => p.category === selectedCategory);

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map(cat => (
            <Button
              key={cat}
              variant={selectedCategory === cat ? 'default' : 'outline'}
              onClick={() => setSelectedCategory(cat)}
              className="capitalize"
            >
              {cat === 'all' ? 'الكل' : cat === 'wisdom' ? 'حكمة' : cat === 'story' ? 'قصة' : 'خدمة'}
            </Button>
          ))}
        </div>

        <div className="space-y-4">
          {filteredPosts.map(post => (
            <Card key={post.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold mb-2">{post.title}</h3>
                    <p className="text-sm text-muted-foreground">
                      بواسطة {post.authorName} • {new Date(post.createdAt).toLocaleDateString('ar')}
                    </p>
                  </div>
                  <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                    {post.category === 'wisdom' ? 'حكمة' : post.category === 'story' ? 'قصة' : 'خدمة'}
                  </span>
                </div>

                <p className="text-gray-700 mb-4 line-clamp-3">{post.content}</p>

                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleLike(post.id)}
                    className={user && post.likedBy.includes(user.id) ? 'text-red-500' : ''}
                  >
                    <Heart className="w-4 h-4 mr-1" fill={user && post.likedBy.includes(user.id) ? 'currentColor' : 'none'} />
                    {post.likes}
                  </Button>

                  <Link to={`/post/${post.id}`}>
                    <Button variant="ghost" size="sm">
                      <MessageCircle className="w-4 h-4 mr-1" />
                      {post.comments.length}
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredPosts.length === 0 && (
            <Card>
              <CardContent className="p-12 text-center">
                <p className="text-muted-foreground">لا توجد منشورات في هذه الفئة</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
};
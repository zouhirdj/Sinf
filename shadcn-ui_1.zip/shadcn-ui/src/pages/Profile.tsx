import React from 'react';
import { Layout } from '@/components/Layout';
import { useAuth } from '@/contexts/AuthContext';
import { getPosts } from '@/lib/storage';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Coins, FileText, Heart, MessageCircle, ShoppingBag } from 'lucide-react';

export const Profile: React.FC = () => {
  const { user } = useAuth();
  
  if (!user) return null;
  
  const userPosts = getPosts().filter(p => p.authorId === user.id);

  const stats = [
    {
      icon: FileText,
      label: 'المنشورات',
      value: userPosts.length,
      color: 'text-blue-600'
    },
    {
      icon: Heart,
      label: 'الإعجابات',
      value: userPosts.reduce((sum, p) => sum + p.likes, 0),
      color: 'text-red-600'
    },
    {
      icon: MessageCircle,
      label: 'التعليقات',
      value: userPosts.reduce((sum, p) => sum + p.comments.length, 0),
      color: 'text-green-600'
    },
    {
      icon: ShoppingBag,
      label: 'المشتريات',
      value: 0,
      color: 'text-purple-600'
    }
  ];

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Profile Header */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center space-y-4">
              <Avatar className="w-24 h-24">
                <AvatarFallback className="text-2xl bg-[#4CD964] text-white">{user.name[0]}</AvatarFallback>
              </Avatar>
              
              <div>
                <h1 className="text-2xl font-bold">{user.name}</h1>
                <p className="text-gray-600">{user.email}</p>
              </div>
              
              <div className="flex items-center gap-2 bg-[#FFC400]/20 px-4 py-2 rounded-full">
                <Coins className="w-5 h-5 text-[#FFC400]" />
                <span className="font-bold text-lg">{user.points} نقطة</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center space-y-2">
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Points Info */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="font-bold text-lg mb-4">كيفية كسب النقاط</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span>نشر منشور</span>
                <Badge variant="outline">+1 نقطة</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>إضافة تعليق</span>
                <Badge variant="outline">+1 نقطة</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>إعجاب بمنشور</span>
                <Badge variant="outline">+0.5 نقطة</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>الحد اليومي المجاني</span>
                <Badge className="bg-[#FFC400] text-black">30 نقطة</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Posts */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="font-bold text-lg mb-4">آخر المنشورات</h3>
            <div className="space-y-3">
              {userPosts.slice(0, 5).map((post) => (
                <div key={post.id} className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm line-clamp-2">{post.content}</p>
                  <div className="flex items-center gap-4 mt-2 text-xs text-gray-600">
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      {post.likes}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="w-3 h-3" />
                      {post.comments.length}
                    </span>
                  </div>
                </div>
              ))}
              {userPosts.length === 0 && (
                <p className="text-center text-gray-500 py-4">لا توجد منشورات بعد</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};
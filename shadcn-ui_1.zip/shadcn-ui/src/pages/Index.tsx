import { Navigate } from 'react-router-dom';
import { useAuthStore } from '@/lib/auth-store';

export default function Index() {
  const user = useAuthStore((state) => state.user);
  
  // Redirect to feed if logged in, otherwise to login
  return <Navigate to={user ? '/feed' : '/'} replace />;
}
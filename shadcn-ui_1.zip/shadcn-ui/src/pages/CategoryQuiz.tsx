import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';

interface QuizQuestion {
  id: number;
  question: string;
  options: {
    text: string;
    categories: {
      wisdom: number;
      story: number;
      service: number;
    };
  }[];
}

const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: 'ما الذي يجذبك أكثر عند تصفح وسائل التواصل الاجتماعي؟',
    options: [
      { text: 'الحكم والمقولات الملهمة', categories: { wisdom: 3, story: 0, service: 0 } },
      { text: 'القصص والتجارب الشخصية', categories: { wisdom: 0, story: 3, service: 0 } },
      { text: 'العروض والخدمات المفيدة', categories: { wisdom: 0, story: 0, service: 3 } },
      { text: 'مزيج من كل ما سبق', categories: { wisdom: 1, story: 1, service: 1 } }
    ]
  },
  {
    id: 2,
    question: 'عندما تواجه مشكلة، ما هو أول شيء تفعله؟',
    options: [
      { text: 'أبحث عن حكمة أو نصيحة من الأقدمين', categories: { wisdom: 3, story: 0, service: 0 } },
      { text: 'أقرأ قصص نجاح الآخرين في مواقف مشابهة', categories: { wisdom: 0, story: 3, service: 0 } },
      { text: 'أبحث عن خدمة أو حل عملي مباشر', categories: { wisdom: 0, story: 0, service: 3 } },
      { text: 'أجمع معلومات من مصادر متنوعة', categories: { wisdom: 1, story: 1, service: 1 } }
    ]
  },
  {
    id: 3,
    question: 'ما نوع المحتوى الذي تفضل مشاركته مع الآخرين؟',
    options: [
      { text: 'اقتباسات وحكم ملهمة', categories: { wisdom: 3, story: 0, service: 0 } },
      { text: 'تجاربي الشخصية وقصصي', categories: { wisdom: 0, story: 3, service: 0 } },
      { text: 'معلومات عن خدمات أو منتجات مفيدة', categories: { wisdom: 0, story: 0, service: 3 } },
      { text: 'محتوى متنوع حسب المناسبة', categories: { wisdom: 1, story: 1, service: 1 } }
    ]
  },
  {
    id: 4,
    question: 'كيف تقضي وقت فراغك عادة؟',
    options: [
      { text: 'قراءة كتب الفلسفة والحكمة', categories: { wisdom: 3, story: 0, service: 0 } },
      { text: 'مشاهدة أفلام وقراءة روايات', categories: { wisdom: 0, story: 3, service: 0 } },
      { text: 'البحث عن فرص وخدمات جديدة', categories: { wisdom: 0, story: 0, service: 3 } },
      { text: 'أنشطة متنوعة حسب المزاج', categories: { wisdom: 1, story: 1, service: 1 } }
    ]
  },
  {
    id: 5,
    question: 'ما الذي يحفزك للتفاعل مع منشور معين؟',
    options: [
      { text: 'عمق الفكرة والحكمة فيه', categories: { wisdom: 3, story: 0, service: 0 } },
      { text: 'القصة المؤثرة والعاطفية', categories: { wisdom: 0, story: 3, service: 0 } },
      { text: 'الفائدة العملية والمباشرة', categories: { wisdom: 0, story: 0, service: 3 } },
      { text: 'أي محتوى جيد بغض النظر عن نوعه', categories: { wisdom: 1, story: 1, service: 1 } }
    ]
  }
];

const categoryInfo = {
  wisdom: { name: 'باحث عن الحكمة', description: 'تفضل المحتوى الفلسفي والحكم العميقة', color: 'bg-purple-100 text-purple-800' },
  story: { name: 'محب القصص', description: 'تفضل القصص والتجارب الشخصية المؤثرة', color: 'bg-blue-100 text-blue-800' },
  service: { name: 'باحث عن الخدمات', description: 'تفضل المحتوى العملي والخدمات المفيدة', color: 'bg-green-100 text-green-800' }
};

export const CategoryQuiz: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { completeProfile } = useAuth();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [scores, setScores] = useState({ wisdom: 0, story: 0, service: 0 });
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showResults, setShowResults] = useState(false);

  const userId = location.state?.userId;

  if (!userId) {
    navigate('/login');
    return null;
  }

  const handleOptionSelect = (optionIndex: number) => {
    setSelectedOption(optionIndex);
  };

  const handleNext = () => {
    if (selectedOption === null) return;

    const option = quizQuestions[currentQuestion].options[selectedOption];
    const newScores = {
      wisdom: scores.wisdom + option.categories.wisdom,
      story: scores.story + option.categories.story,
      service: scores.service + option.categories.service
    };
    setScores(newScores);

    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedOption(null);
    } else {
      setShowResults(true);
    }
  };

  const handleComplete = async () => {
    // Determine primary category
    const maxScore = Math.max(scores.wisdom, scores.story, scores.service);
    let profileId = '4'; // Default to balanced
    
    if (scores.wisdom === maxScore && scores.wisdom > scores.story && scores.wisdom > scores.service) {
      profileId = '1'; // Wisdom seeker
    } else if (scores.story === maxScore && scores.story > scores.wisdom && scores.story > scores.service) {
      profileId = '2'; // Story lover
    } else if (scores.service === maxScore && scores.service > scores.wisdom && scores.service > scores.story) {
      profileId = '3'; // Service seeker
    }

    await completeProfile(userId, profileId);
    navigate('/');
  };

  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;

  if (showResults) {
    const sortedCategories = Object.entries(scores)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 2);

    return (
      <div className="min-h-screen bg-gradient-to-br from-[#4CD964]/10 to-[#FFC400]/10 flex items-center justify-center p-4" dir="rtl">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">نتائج التصنيف</CardTitle>
            <CardDescription>تم تحليل إجاباتك بنجاح!</CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="text-center">
              <p className="text-lg mb-4">فئاتك المفضلة:</p>
              <div className="space-y-3">
                {sortedCategories.map(([category, score]) => {
                  const info = categoryInfo[category as keyof typeof categoryInfo];
                  return (
                    <div key={category} className="space-y-2">
                      <Badge className={`${info.color} text-lg px-4 py-2`}>
                        {info.name}
                      </Badge>
                      <p className="text-sm text-gray-600">{info.description}</p>
                      <div className="flex items-center gap-2">
                        <Progress value={(score / 15) * 100} className="flex-1" />
                        <span className="text-sm font-semibold">{score} نقطة</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-[#FFC400]/10 border border-[#FFC400]/30 rounded-lg p-4 text-center">
              <p className="text-sm">
                🎉 تهانينا! حصلت على <span className="font-bold text-[#FFC400]">30 نقطة مجانية</span> للبدء!
              </p>
            </div>

            <Button
              onClick={handleComplete}
              className="w-full bg-[#4CD964] hover:bg-[#4CD964]/90 text-lg py-6"
            >
              ابدأ الاستخدام
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const question = quizQuestions[currentQuestion];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#4CD964]/10 to-[#FFC400]/10 flex items-center justify-center p-4" dir="rtl">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">أسئلة التصنيف</CardTitle>
              <Badge variant="outline">
                {currentQuestion + 1} / {quizQuestions.length}
              </Badge>
            </div>
            <Progress value={progress} />
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold mb-4">{question.question}</h3>
            
            <div className="space-y-3">
              {question.options.map((option, index) => (
                <Button
                  key={index}
                  variant={selectedOption === index ? 'default' : 'outline'}
                  className={`w-full justify-start text-right h-auto py-4 ${
                    selectedOption === index ? 'bg-[#4CD964] hover:bg-[#4CD964]/90' : ''
                  }`}
                  onClick={() => handleOptionSelect(index)}
                >
                  <span className="text-base">{option.text}</span>
                </Button>
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            {currentQuestion > 0 && (
              <Button
                variant="outline"
                onClick={() => {
                  setCurrentQuestion(currentQuestion - 1);
                  setSelectedOption(null);
                }}
                className="flex-1"
              >
                السابق
              </Button>
            )}
            <Button
              onClick={handleNext}
              disabled={selectedOption === null}
              className="flex-1 bg-[#4CD964] hover:bg-[#4CD964]/90"
            >
              {currentQuestion === quizQuestions.length - 1 ? 'إنهاء' : 'التالي'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/Layout';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Coins, Download, Star } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  downloads: number;
  rating: number;
}

const mockProducts: Product[] = [
  {
    id: '1',
    name: 'كتاب التنمية الذاتية',
    description: 'دليل شامل للتطوير الشخصي والنجاح',
    price: 50,
    category: 'كتب',
    image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400',
    downloads: 1234,
    rating: 4.8
  },
  {
    id: '2',
    name: 'دورة البرمجة',
    description: 'تعلم البرمجة من الصفر حتى الاحتراف',
    price: 100,
    category: 'دورات',
    image: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=400',
    downloads: 856,
    rating: 4.9
  }
];

const rechargeCards: Record<string, number> = {
  'z50-006-50G': 50,
  'z100-02B-3YS': 100,
  'z200-02P-ZSS': 200
};

export const Store: React.FC = () => {
  const { user } = useAuth();
  const [products] = useState<Product[]>(mockProducts);
  const [purchases, setPurchases] = useState<string[]>([]);
  const [rechargeCode, setRechargeCode] = useState('');
  const [usedCodes, setUsedCodes] = useState<string[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem('purchases');
    if (stored) setPurchases(JSON.parse(stored));
    
    const storedCodes = localStorage.getItem('usedCodes');
    if (storedCodes) setUsedCodes(JSON.parse(storedCodes));
  }, []);

  const handlePurchase = (product: Product) => {
    if (!user) return;
    
    if (user.points < product.price) {
      alert('رصيدك غير كافٍ لشراء هذا المنتج');
      return;
    }
    
    const newPurchases = [...purchases, product.id];
    setPurchases(newPurchases);
    localStorage.setItem('purchases', JSON.stringify(newPurchases));
    alert('تم الشراء بنجاح! يمكنك تحميل المنتج الآن');
  };

  const handleRecharge = () => {
    if (!rechargeCode.trim()) return;
    
    if (usedCodes.includes(rechargeCode)) {
      alert('هذا الكود مستخدم من قبل');
      return;
    }
    
    const amount = rechargeCards[rechargeCode];
    if (amount) {
      const newUsedCodes = [...usedCodes, rechargeCode];
      setUsedCodes(newUsedCodes);
      localStorage.setItem('usedCodes', JSON.stringify(newUsedCodes));
      setRechargeCode('');
      alert(`تم شحن ${amount} نقطة بنجاح!`);
    } else {
      alert('الكود غير صحيح');
    }
  };

  const isPurchased = (productId: string) => purchases.includes(productId);

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Recharge Section */}
        <Card className="bg-gradient-to-r from-[#FFC400]/20 to-[#4CD964]/20">
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Coins className="w-6 h-6 text-[#FFC400]" />
                <h2 className="text-xl font-bold">شحن النقاط</h2>
              </div>
              
              <p className="text-sm text-gray-600">
                أدخل كود الشحن للحصول على نقاط إضافية (50، 100، أو 200 نقطة)
              </p>
              
              <div className="flex gap-2">
                <Input
                  placeholder="أدخل كود الشحن (مثال: z50-006-50G)"
                  value={rechargeCode}
                  onChange={(e) => setRechargeCode(e.target.value)}
                  className="flex-1"
                />
                <Button
                  onClick={handleRecharge}
                  className="bg-[#FFC400] hover:bg-[#FFC400]/90 text-black"
                >
                  شحن
                </Button>
              </div>
              
              <div className="text-xs text-gray-500">
                أكواد تجريبية: z50-006-50G، z100-02B-3YS، z200-02P-ZSS
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Products Grid */}
        <div>
          <h2 className="text-2xl font-bold mb-4">المنتجات الرقمية</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {products.map((product) => (
              <Card key={product.id}>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                    
                    <div>
                      <Badge className="mb-2">{product.category}</Badge>
                      <h3 className="font-bold text-lg">{product.name}</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        {product.description}
                      </p>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Download className="w-4 h-4" />
                        {product.downloads} تحميل
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        {product.rating.toFixed(1)}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between pt-2 border-t">
                      <div className="flex items-center gap-1 text-[#FFC400] font-bold text-lg">
                        <Coins className="w-5 h-5" />
                        {product.price}
                      </div>
                      
                      {isPurchased(product.id) ? (
                        <Button
                          variant="outline"
                          className="text-green-600 border-green-600"
                        >
                          <Download className="w-4 h-4 ml-2" />
                          تحميل
                        </Button>
                      ) : (
                        <Button
                          onClick={() => handlePurchase(product)}
                          className="bg-[#4CD964] hover:bg-[#4CD964]/90"
                        >
                          شراء
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
};
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/Layout';
import { useAuth } from '@/contexts/AuthContext';
import { getPostById, savePost, Post, Comment } from '@/lib/storage';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Heart, MessageCircle, ArrowLeft } from 'lucide-react';

export const PostDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [post, setPost] = useState<Post | null>(null);
  const [commentText, setCommentText] = useState('');

  useEffect(() => {
    if (id) {
      const foundPost = getPostById(id);
      if (foundPost) {
        setPost(foundPost);
      }
    }
  }, [id]);

  const handleLike = () => {
    if (!user || !post) return;

    const hasLiked = post.likedBy.includes(user.id);
    
    if (hasLiked) {
      post.likedBy = post.likedBy.filter(userId => userId !== user.id);
      post.likes--;
    } else {
      post.likedBy.push(user.id);
      post.likes++;
    }
    
    savePost(post);
    setPost({ ...post });
  };

  const handleComment = () => {
    if (!user || !post || !commentText.trim()) return;

    const newComment: Comment = {
      id: Date.now().toString(),
      authorId: user.id,
      authorName: user.name,
      content: commentText,
      createdAt: new Date().toISOString(),
    };

    post.comments.push(newComment);
    savePost(post);
    setPost({ ...post });
    setCommentText('');
  };

  if (!post) {
    return (
      <Layout>
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-12 text-center">
              <p className="text-muted-foreground">المنشور غير موجود</p>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-6">
        <Button variant="ghost" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4 ml-2" />
          رجوع
        </Button>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="text-2xl font-bold mb-2">{post.title}</h1>
                <p className="text-sm text-muted-foreground">
                  بواسطة {post.authorName} • {new Date(post.createdAt).toLocaleDateString('ar')}
                </p>
              </div>
              <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                {post.category === 'wisdom' ? 'حكمة' : post.category === 'story' ? 'قصة' : 'خدمة'}
              </span>
            </div>

            <p className="text-gray-700 mb-6 whitespace-pre-wrap">{post.content}</p>

            <div className="flex items-center gap-4 pt-4 border-t">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLike}
                className={user && post.likedBy.includes(user.id) ? 'text-red-500' : ''}
              >
                <Heart className="w-4 h-4 mr-1" fill={user && post.likedBy.includes(user.id) ? 'currentColor' : 'none'} />
                {post.likes}
              </Button>

              <div className="flex items-center gap-1">
                <MessageCircle className="w-4 h-4" />
                <span className="text-sm">{post.comments.length}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-bold mb-4">التعليقات</h2>

            {user && (
              <div className="mb-6 space-y-2">
                <Textarea
                  placeholder="اكتب تعليقك..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="min-h-[100px]"
                />
                <Button onClick={handleComment} disabled={!commentText.trim()}>
                  إضافة تعليق
                </Button>
              </div>
            )}

            <div className="space-y-4">
              {post.comments.map(comment => (
                <div key={comment.id} className="border-b pb-4 last:border-b-0">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold">{comment.authorName}</span>
                    <span className="text-sm text-muted-foreground">
                      {new Date(comment.createdAt).toLocaleDateString('ar')}
                    </span>
                  </div>
                  <p className="text-gray-700">{comment.content}</p>
                </div>
              ))}

              {post.comments.length === 0 && (
                <p className="text-center text-muted-foreground py-8">
                  لا توجد تعليقات بعد
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};
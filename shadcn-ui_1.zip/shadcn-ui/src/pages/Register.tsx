import RegisterForm from '@/components/auth/RegisterForm';

export default function Register() {
  return (
    <div 
      className="min-h-screen flex items-center justify-center p-4"
      style={{
        backgroundImage: 'url(/assets/hero-banner.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" />
      <div className="relative z-10">
        <RegisterForm />
      </div>
    </div>
  );
}
import { create } from 'zustand';
import { supabase } from './supabase';
import type { User } from '@/types';
import type { Session } from '@supabase/supabase-js';

interface AuthState {
  user: User | null;
  session: Session | null;
  loading: boolean;
  setUser: (user: User | null) => void;
  setSession: (session: Session | null) => void;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, name: string, phone: string) => Promise<void>;
  signOut: () => Promise<void>;
  initialize: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  session: null,
  loading: true,

  setUser: (user) => set({ user }),
  setSession: (session) => set({ session }),

  signIn: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;

    if (data.user) {
      // Fetch user profile
      const { data: profile } = await supabase
        .from('app_fcb82_users')
        .select('*')
        .eq('user_id', data.user.id)
        .single();

      set({ user: profile, session: data.session });
    }
  },

  signUp: async (email: string, password: string, name: string, phone: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) throw error;

    if (data.user) {
      // Create user profile
      const { data: profile } = await supabase
        .from('app_fcb82_users')
        .insert({
          user_id: data.user.id,
          name,
          phone,
          cognitive_profile_id: 1,
          points_balance: 30,
          zizo_balance: 0,
          real_user: true,
          bot: false,
        })
        .select()
        .single();

      set({ user: profile, session: data.session });
    }
  },

  signOut: async () => {
    await supabase.auth.signOut();
    set({ user: null, session: null });
  },

  initialize: async () => {
    set({ loading: true });
    
    const { data: { session } } = await supabase.auth.getSession();
    
    if (session?.user) {
      const { data: profile } = await supabase
        .from('app_fcb82_users')
        .select('*')
        .eq('user_id', session.user.id)
        .single();

      set({ user: profile, session, loading: false });
    } else {
      set({ loading: false });
    }

    // Listen for auth changes
    supabase.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        const { data: profile } = await supabase
          .from('app_fcb82_users')
          .select('*')
          .eq('user_id', session.user.id)
          .single();

        set({ user: profile, session });
      } else {
        set({ user: null, session: null });
      }
    });
  },
}));
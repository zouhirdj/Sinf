import { User, Post, Product, RechargeCard, CognitiveProfile } from '@/types';

export const cognitiveProfiles: CognitiveProfile[] = [
  {
    id: '1',
    name: 'Wisdom Seeker',
    nameAr: 'باحث عن الحكمة',
    description: 'يفضل المحتوى الفلسفي والحكم',
    weights: { wisdom: 0.7, story: 0.2, service: 0.1 }
  },
  {
    id: '2',
    name: 'Story Lover',
    nameAr: 'محب القصص',
    description: 'يفضل القصص والتجارب الشخصية',
    weights: { wisdom: 0.2, story: 0.7, service: 0.1 }
  },
  {
    id: '3',
    name: 'Service Seeker',
    nameAr: 'باحث عن الخدمات',
    description: 'يفضل العروض والخدمات',
    weights: { wisdom: 0.1, story: 0.2, service: 0.7 }
  },
  {
    id: '4',
    name: 'Balanced',
    nameAr: 'متوازن',
    description: 'يحب جميع أنواع المحتوى بالتساوي',
    weights: { wisdom: 0.33, story: 0.33, service: 0.34 }
  }
];

const arabicNames = [
  'أحمد محمد', 'فاطمة علي', 'محمد حسن', 'عائشة خالد', 'عمر يوسف',
  'خديجة سعيد', 'علي أحمد', 'مريم حسين', 'حسن عبدالله', 'سارة محمود',
  'يوسف إبراهيم', 'نور الدين', 'ليلى عمر', 'كريم رشيد', 'هدى سليم',
  'طارق فهد', 'رانيا ناصر', 'سامي وليد', 'ياسمين زياد', 'وليد طارق',
  'دينا صلاح', 'ماجد عادل', 'سلمى كمال', 'عادل منير', 'لينا جمال',
  'نبيل فاروق', 'منى سمير', 'رامي شريف', 'هالة نبيل', 'شريف ماهر',
  'إيمان رضا', 'جمال حمدي', 'سميرة عزيز', 'حمدي فتحي', 'نادية وائل',
  'فتحي صابر', 'ريم طلال', 'صابر عماد', 'نهى باسم', 'عماد سامح',
  'باسم رفيق', 'سهام نادر', 'رفيق جابر', 'وفاء حازم', 'جابر مازن',
  'حازم ثابت', 'أمل راشد', 'ثابت عاصم', 'سعاد غازي', 'عاصم فايز'
];

export const generateBotUsers = (): User[] => {
  return arabicNames.map((name, index) => ({
    id: `bot-${index + 1}`,
    name,
    email: `bot${index + 1}@sinf.com`,
    phone: `+21365${String(index).padStart(7, '0')}`,
    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`,
    bio: 'عضو في منصة صِنف',
    cognitiveProfile: cognitiveProfiles[index % 4].id,
    zizoBalance: 0,
    role: 'bot',
    isBot: true,
    createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString()
  }));
};

const wisdomPosts = [
  'الصبر مفتاح الفرج، والعجلة من الشيطان',
  'من طلب العلا سهر الليالي',
  'العلم نور والجهل ظلام',
  'الصديق وقت الضيق',
  'من جد وجد ومن زرع حصد',
  'الوقت كالسيف إن لم تقطعه قطعك',
  'درهم وقاية خير من قنطار علاج',
  'اطلب العلم من المهد إلى اللحد',
  'الحكمة ضالة المؤمن',
  'خير الناس أنفعهم للناس'
];

const storyPosts = [
  'قصة نجاحي في تعلم البرمجة بدأت من الصفر، واليوم أنا مطور محترف',
  'رحلتي في تأسيس مشروعي الخاص علمتني الكثير عن الصبر والمثابرة',
  'تجربتي مع التطوع في الجمعيات الخيرية غيرت نظرتي للحياة',
  'كيف تغلبت على الخوف من الفشل وحققت أحلامي',
  'قصة صداقة استمرت 20 عاماً رغم المسافات',
  'تجربتي في السفر حول العالم علمتني احترام الثقافات المختلفة',
  'كيف ساعدني الفشل في الوصول إلى النجاح',
  'رحلة التعافي من المرض علمتني قيمة الصحة',
  'قصة كفاحي للحصول على شهادة الدكتوراه',
  'تجربتي في تعلم لغة جديدة بعد سن الأربعين'
];

const servicePosts = [
  'خدمات تصميم جرافيك احترافية بأسعار مناسبة',
  'دورات تدريبية في البرمجة والتطوير',
  'خدمات الترجمة من وإلى العربية',
  'استشارات قانونية مجانية للساعة الأولى',
  'تصميم مواقع إلكترونية متجاوبة',
  'دروس خصوصية في الرياضيات والفيزياء',
  'خدمات التسويق الإلكتروني والسوشيال ميديا',
  'تطوير تطبيقات الموبايل iOS و Android',
  'خدمات المحاسبة والاستشارات المالية',
  'دورات في اللغة الإنجليزية للمبتدئين'
];

export const generateMockPosts = (users: User[]): Post[] => {
  const posts: Post[] = [];
  const types: ('wisdom' | 'story' | 'service')[] = ['wisdom', 'story', 'service'];
  
  for (let i = 0; i < 100; i++) {
    const type = types[i % 3];
    const author = users[Math.floor(Math.random() * users.length)];
    let content = '';
    
    if (type === 'wisdom') {
      content = wisdomPosts[i % wisdomPosts.length];
    } else if (type === 'story') {
      content = storyPosts[i % storyPosts.length];
    } else {
      content = servicePosts[i % servicePosts.length];
    }
    
    posts.push({
      id: `post-${i + 1}`,
      authorId: author.id,
      author,
      type,
      title: '',
      content,
      likes: Math.floor(Math.random() * 50),
      comments: Math.floor(Math.random() * 20),
      likedBy: [],
      createdAt: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString()
    });
  }
  
  return posts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
};

export const generateMockProducts = (users: User[]): Product[] => {
  const products = [
    { name: 'كتاب إلكتروني: دليل البرمجة', price: 50, category: 'كتب' },
    { name: 'قالب موقع احترافي', price: 100, category: 'قوالب' },
    { name: 'دورة تصميم جرافيك', price: 150, category: 'دورات' },
    { name: 'ملف PSD تصميم لوجو', price: 30, category: 'تصاميم' },
    { name: 'كتاب: التسويق الرقمي', price: 80, category: 'كتب' },
    { name: 'قالب تطبيق موبايل', price: 200, category: 'قوالب' },
    { name: 'دورة تطوير الويب', price: 180, category: 'دورات' },
    { name: 'مجموعة أيقونات SVG', price: 40, category: 'تصاميم' },
    { name: 'كتاب: إدارة المشاريع', price: 60, category: 'كتب' },
    { name: 'قالب لوحة تحكم', price: 120, category: 'قوالب' }
  ];
  
  return products.map((product, index) => ({
    id: `product-${index + 1}`,
    sellerId: users[index % users.length].id,
    seller: users[index % users.length],
    name: product.name,
    description: `${product.name} - منتج رقمي عالي الجودة`,
    price: product.price,
    image: `https://picsum.photos/seed/${index}/400/300`,
    category: product.category,
    downloads: Math.floor(Math.random() * 100),
    rating: 4 + Math.random(),
    createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString()
  }));
};

export const rechargeCards: RechargeCard[] = [
  { code: 'z50-006-50G', amount: 50, used: false },
  { code: 'z50-009-1F2', amount: 50, used: false },
  { code: 'z100-02B-3YS', amount: 100, used: false },
  { code: 'z100-038-AHZ', amount: 100, used: false },
  { code: 'z200-02P-ZSS', amount: 200, used: false },
  { code: 'z200-03U-500', amount: 200, used: false }
];
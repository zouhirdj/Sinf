export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  points: number;
  categoryScores: Record<string, number>;
  createdAt: string;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  category: string;
  title: string;
  content: string;
  likes: number;
  likedBy: string[];
  comments: Comment[];
  createdAt: string;
}

export interface Comment {
  id: string;
  authorId: string;
  authorName: string;
  content: string;
  createdAt: string;
}

const USERS_KEY = 'sinf_users';
const POSTS_KEY = 'sinf_posts';

export const getUsers = (): User[] => {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
};

export const saveUser = (user: User): void => {
  const users = getUsers();
  const index = users.findIndex(u => u.id === user.id);
  if (index >= 0) {
    users[index] = user;
  } else {
    users.push(user);
  }
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const getUserByEmail = (email: string): User | undefined => {
  const users = getUsers();
  return users.find(u => u.email === email);
};

export const getUserById = (id: string): User | undefined => {
  const users = getUsers();
  return users.find(u => u.id === id);
};

export const getPosts = (): Post[] => {
  const posts = localStorage.getItem(POSTS_KEY);
  return posts ? JSON.parse(posts) : [];
};

export const savePost = (post: Post): void => {
  const posts = getPosts();
  const index = posts.findIndex(p => p.id === post.id);
  if (index >= 0) {
    posts[index] = post;
  } else {
    posts.push(post);
  }
  localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
};

export const getPostById = (id: string): Post | undefined => {
  const posts = getPosts();
  return posts.find(p => p.id === id);
};

export const updateUserPoints = (userId: string, points: number): void => {
  const users = getUsers();
  const user = users.find(u => u.id === userId);
  if (user) {
    user.points = points;
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }
};

export const updateUserCategoryScore = (userId: string, category: string, score: number): void => {
  const users = getUsers();
  const user = users.find(u => u.id === userId);
  if (user) {
    user.categoryScores[category] = score;
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }
};
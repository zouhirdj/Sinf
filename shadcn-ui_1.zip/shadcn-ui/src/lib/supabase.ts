import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database helper functions
export const db = {
  // Users
  async getUser(userId: string) {
    const { data, error } = await supabase
      .from('app_fcb82_users')
      .select('*')
      .eq('user_id', userId)
      .single();
    
    if (error) throw error;
    return data;
  },

  async updateUserPoints(userId: string, points: number, zizoBalance: number) {
    const { data, error } = await supabase
      .from('app_fcb82_users')
      .update({ points_balance: points, zizo_balance: zizoBalance })
      .eq('user_id', userId)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  // Posts
  async getPosts(limit = 20, offset = 0) {
    const { data, error } = await supabase
      .from('app_fcb82_posts')
      .select(`
        *,
        author:app_fcb82_users!app_fcb82_posts_author_id_fkey(user_id, name)
      `)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (error) throw error;
    return data;
  },

  async createPost(authorId: string, type: string, content: string) {
    const { data, error } = await supabase
      .from('app_fcb82_posts')
      .insert({
        author_id: authorId,
        type,
        content,
        media_urls: []
      })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async deletePost(postId: string) {
    const { error } = await supabase
      .from('app_fcb82_posts')
      .delete()
      .eq('post_id', postId);
    
    if (error) throw error;
  },

  // Likes
  async toggleLike(postId: string, userId: string) {
    // Check if like exists
    const { data: existingLike } = await supabase
      .from('app_fcb82_likes')
      .select('like_id')
      .eq('post_id', postId)
      .eq('user_id', userId)
      .single();

    if (existingLike) {
      // Unlike
      await supabase
        .from('app_fcb82_likes')
        .delete()
        .eq('like_id', existingLike.like_id);
      
      // Decrement count
      await supabase.rpc('decrement_likes', { post_id: postId });
      return false;
    } else {
      // Like
      await supabase
        .from('app_fcb82_likes')
        .insert({ post_id: postId, user_id: userId });
      
      // Increment count
      await supabase.rpc('increment_likes', { post_id: postId });
      return true;
    }
  },

  async getUserLikes(userId: string) {
    const { data, error } = await supabase
      .from('app_fcb82_likes')
      .select('post_id')
      .eq('user_id', userId);
    
    if (error) throw error;
    return data.map(like => like.post_id);
  },

  // Comments
  async getComments(postId: string) {
    const { data, error } = await supabase
      .from('app_fcb82_comments')
      .select(`
        *,
        user:app_fcb82_users!app_fcb82_comments_user_id_fkey(user_id, name)
      `)
      .eq('post_id', postId)
      .order('created_at', { ascending: true });
    
    if (error) throw error;
    return data;
  },

  async createComment(postId: string, userId: string, content: string) {
    const { data, error } = await supabase
      .from('app_fcb82_comments')
      .insert({
        post_id: postId,
        user_id: userId,
        content
      })
      .select()
      .single();
    
    if (error) throw error;

    // Increment comment count
    await supabase.rpc('increment_comments', { post_id: postId });
    
    return data;
  },

  // Recharge
  async redeemCode(code: string, userId: string) {
    // Check if code exists and is unused
    const { data: card, error: fetchError } = await supabase
      .from('app_fcb82_recharge_cards')
      .select('*')
      .eq('code', code)
      .eq('used', false)
      .single();

    if (fetchError || !card) {
      throw new Error('الكود غير صالح أو مستخدم مسبقاً');
    }

    // Mark as used
    const { error: updateError } = await supabase
      .from('app_fcb82_recharge_cards')
      .update({
        used: true,
        used_by: userId,
        used_at: new Date().toISOString()
      })
      .eq('code', code);

    if (updateError) throw updateError;

    // Get current user balance
    const user = await this.getUser(userId);
    const newZizoBalance = user.zizo_balance + card.points;

    // Update user balance
    await this.updateUserPoints(userId, user.points_balance, newZizoBalance);

    // Record transaction
    await supabase
      .from('app_fcb82_points_history')
      .insert({
        user_id: userId,
        amount: card.points,
        type: 'recharged',
        description: `تم شحن ${card.points} نقطة Zizo`
      });

    return { points: card.points, newBalance: newZizoBalance };
  }
};
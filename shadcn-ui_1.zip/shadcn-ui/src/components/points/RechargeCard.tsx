import { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { db } from '@/lib/supabase';
import { useAuthStore } from '@/lib/auth-store';
import { toast } from 'sonner';

export default function RechargeCard() {
  const user = useAuthStore((state) => state.user);
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !user) return;

    setLoading(true);
    try {
      const result = await db.redeemCode(code.trim(), user.user_id);
      toast.success(`تم شحن ${result.points} نقطة Zizo بنجاح!`);
      setCode('');
      
      // Update user in store
      useAuthStore.setState({
        user: { ...user, zizo_balance: result.newBalance }
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'فشل شحن الكود';
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-3">
          <img src="/assets/logo-zizo_variant_4.png" alt="Zizo" className="w-12 h-12" />
          <div>
            <CardTitle>شحن نقاط Zizo</CardTitle>
            <CardDescription>أدخل كود الشحن للحصول على النقاط</CardDescription>
          </div>
        </div>
      </CardHeader>
      <form onSubmit={handleRedeem}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="code">كود الشحن</Label>
            <Input
              id="code"
              type="text"
              placeholder="z50-XXX-XXX"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              disabled={loading}
              dir="ltr"
              className="text-center font-mono text-lg"
            />
          </div>
          
          <div className="bg-[#FFC400]/10 rounded-lg p-4">
            <p className="text-sm text-center">
              رصيدك الحالي: <span className="font-bold text-[#FFC400] text-lg">{user?.zizo_balance || 0}</span> نقطة
            </p>
          </div>
        </CardContent>
        <CardFooter>
          <Button
            type="submit"
            className="w-full bg-[#FFC400] hover:bg-[#e6b000] text-black font-semibold"
            disabled={!code.trim() || loading}
          >
            {loading ? 'جاري الشحن...' : 'شحن الآن'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
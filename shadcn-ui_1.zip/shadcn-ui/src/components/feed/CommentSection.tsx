import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Send } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';
import { db } from '@/lib/supabase';
import { useAuthStore } from '@/lib/auth-store';
import type { Comment } from '@/types';
import { toast } from 'sonner';

interface CommentSectionProps {
  postId: string;
  onCommentAdded?: () => void;
}

export default function CommentSection({ postId, onCommentAdded }: CommentSectionProps) {
  const user = useAuthStore((state) => state.user);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    loadComments();
  }, [postId]);

  const loadComments = async () => {
    setLoading(true);
    try {
      const data = await db.getComments(postId);
      setComments(data);
    } catch (error) {
      console.error('Failed to load comments:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !user) return;

    setSubmitting(true);
    try {
      const comment = await db.createComment(postId, user.user_id, newComment.trim());
      setComments([...comments, { ...comment, user: { user_id: user.user_id, name: user.name } }]);
      setNewComment('');
      onCommentAdded?.();
      toast.success('تم إضافة التعليق');
    } catch (error) {
      toast.error('فشل إضافة التعليق');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="w-full space-y-4">
      {/* Comment Form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <Avatar className="h-8 w-8">
          <AvatarImage src="/assets/default-avatar_variant_2.png" />
          <AvatarFallback>{user?.name?.charAt(0) || 'U'}</AvatarFallback>
        </Avatar>
        <div className="flex-1 flex gap-2">
          <Textarea
            placeholder="اكتب تعليقاً..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="min-h-[60px] resize-none"
            disabled={submitting}
          />
          <Button
            type="submit"
            size="icon"
            className="bg-[#4CD964] hover:bg-[#3cb54f]"
            disabled={!newComment.trim() || submitting}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </form>

      {/* Comments List */}
      <div className="space-y-3">
        {loading ? (
          <p className="text-sm text-muted-foreground text-center">جاري التحميل...</p>
        ) : comments.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center">لا توجد تعليقات بعد</p>
        ) : (
          comments.map((comment) => (
            <div key={comment.comment_id} className="flex gap-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src="/assets/default-avatar_variant_3.png" />
                <AvatarFallback>{comment.user?.name?.charAt(0) || 'U'}</AvatarFallback>
              </Avatar>
              <div className="flex-1 bg-gray-100 rounded-lg p-3">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-semibold">{comment.user?.name || 'مستخدم'}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(comment.created_at), { 
                      addSuffix: true, 
                      locale: ar 
                    })}
                  </p>
                </div>
                <p className="text-sm">{comment.content}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
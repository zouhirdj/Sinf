import { useState } from 'react';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Heart, MessageCircle, Trash2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';
import type { Post } from '@/types';
import { useAuthStore } from '@/lib/auth-store';
import { db } from '@/lib/supabase';
import { toast } from 'sonner';
import CommentSection from './CommentSection';

interface PostCardProps {
  post: Post;
  userLikes: string[];
  onLikeToggle: (postId: string) => void;
  onDelete?: (postId: string) => void;
}

export default function PostCard({ post, userLikes, onLikeToggle, onDelete }: PostCardProps) {
  const user = useAuthStore((state) => state.user);
  const [showComments, setShowComments] = useState(false);
  const [commentsCount, setCommentsCount] = useState(post.comments_count);
  const isLiked = userLikes.includes(post.post_id);
  const isOwner = user?.user_id === post.author_id;

  const getPostTypeLabel = (type: string) => {
    switch (type) {
      case 'wisdom':
        return 'حكمة';
      case 'story':
        return 'قصة';
      case 'service':
        return 'خدمة';
      default:
        return type;
    }
  };

  const getPostTypeBadge = (type: string) => {
    const colors = {
      wisdom: 'bg-blue-100 text-blue-800',
      story: 'bg-purple-100 text-purple-800',
      service: 'bg-green-100 text-green-800',
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const handleDelete = async () => {
    if (!window.confirm('هل أنت متأكد من حذف هذا المنشور؟')) return;

    try {
      await db.deletePost(post.post_id);
      toast.success('تم حذف المنشور بنجاح');
      onDelete?.(post.post_id);
    } catch (error) {
      toast.error('فشل حذف المنشور');
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarImage src="/assets/default-avatar_variant_1.png" />
              <AvatarFallback>{post.author?.name?.charAt(0) || 'U'}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold">{post.author?.name || 'مستخدم'}</p>
              <p className="text-xs text-muted-foreground">
                {formatDistanceToNow(new Date(post.created_at), { 
                  addSuffix: true, 
                  locale: ar 
                })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className={getPostTypeBadge(post.type)}>
              {getPostTypeLabel(post.type)}
            </Badge>
            {isOwner && (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                onClick={handleDelete}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <p className="text-sm whitespace-pre-wrap">{post.content}</p>
      </CardContent>

      <CardFooter className="flex flex-col gap-4">
        <div className="flex items-center gap-4 w-full">
          <Button
            variant="ghost"
            size="sm"
            className={`gap-2 ${isLiked ? 'text-red-600' : ''}`}
            onClick={() => onLikeToggle(post.post_id)}
          >
            <Heart className={`h-5 w-5 ${isLiked ? 'fill-current' : ''}`} />
            <span>{post.likes_count}</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="gap-2"
            onClick={() => setShowComments(!showComments)}
          >
            <MessageCircle className="h-5 w-5" />
            <span>{commentsCount}</span>
          </Button>
        </div>

        {showComments && (
          <CommentSection 
            postId={post.post_id} 
            onCommentAdded={() => setCommentsCount(prev => prev + 1)}
          />
        )}
      </CardFooter>
    </Card>
  );
}
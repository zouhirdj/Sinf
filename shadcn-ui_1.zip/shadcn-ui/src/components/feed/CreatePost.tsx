import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Send } from 'lucide-react';
import { db } from '@/lib/supabase';
import { useAuthStore } from '@/lib/auth-store';
import { toast } from 'sonner';

interface CreatePostProps {
  onPostCreated: () => void;
}

export default function CreatePost({ onPostCreated }: CreatePostProps) {
  const user = useAuthStore((state) => state.user);
  const [content, setContent] = useState('');
  const [type, setType] = useState<'wisdom' | 'story' | 'service'>('story');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || !user) return;

    setLoading(true);
    try {
      await db.createPost(user.user_id, type, content.trim());
      setContent('');
      setType('story');
      toast.success('تم نشر المنشور بنجاح');
      onPostCreated();
    } catch (error) {
      toast.error('فشل نشر المنشور');
    } finally {
      setLoading(false);
    }
  };

  const handleTypeChange = (value: string) => {
    setType(value as 'wisdom' | 'story' | 'service');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">إنشاء منشور جديد</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-3">
            <Avatar>
              <AvatarImage src="/assets/default-avatar_variant_6.png" />
              <AvatarFallback>{user?.name?.charAt(0) || 'U'}</AvatarFallback>
            </Avatar>
            <Textarea
              placeholder="ماذا تريد أن تشارك؟"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[100px] resize-none"
              disabled={loading}
            />
          </div>
          <Select value={type} onValueChange={handleTypeChange}>
            <SelectTrigger>
              <SelectValue placeholder="نوع المنشور" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="wisdom">حكمة</SelectItem>
              <SelectItem value="story">قصة</SelectItem>
              <SelectItem value="service">خدمة</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
        <CardFooter>
          <Button
            type="submit"
            className="w-full bg-[#4CD964] hover:bg-[#3cb54f] gap-2"
            disabled={!content.trim() || loading}
          >
            <Send className="h-4 w-4" />
            <span>{loading ? 'جاري النشر...' : 'نشر'}</span>
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Home, User, Store, LogOut, Coins } from 'lucide-react';
import { useAuthStore } from '@/lib/auth-store';
import { toast } from 'sonner';

export default function Header() {
  const { user, signOut } = useAuthStore();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      await signOut();
      toast.success('تم تسجيل الخروج بنجاح');
      navigate('/');
    } catch (error) {
      toast.error('فشل تسجيل الخروج');
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        {/* Logo */}
        <Link to="/feed" className="flex items-center gap-2">
          <img src="/assets/logo-sinf_variant_2.png" alt="صِنف" className="w-10 h-10" />
          <span className="text-xl font-bold text-[#4CD964]">صِنف</span>
        </Link>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <Link to="/feed">
            <Button variant="ghost" className="gap-2">
              <Home className="w-5 h-5" />
              <span>الرئيسية</span>
            </Button>
          </Link>
          <Link to="/store">
            <Button variant="ghost" className="gap-2">
              <Store className="w-5 h-5" />
              <span>المتجر</span>
            </Button>
          </Link>
        </nav>

        {/* User Menu */}
        <div className="flex items-center gap-4">
          {/* Zizo Points */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-[#FFC400]/10 rounded-lg">
            <img src="/assets/logo-zizo.png" alt="Zizo" className="w-6 h-6" />
            <span className="font-semibold text-[#FFC400]">{user?.zizo_balance || 0}</span>
          </div>

          {/* Profile Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                <Avatar>
                  <AvatarImage src="/assets/default-avatar.png" alt={user?.name} />
                  <AvatarFallback>{user?.name?.charAt(0) || 'U'}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end">
              <DropdownMenuLabel>
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium">{user?.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {user?.points_balance || 0} نقطة
                  </p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate('/profile')}>
                <User className="ml-2 h-4 w-4" />
                <span>الملف الشخصي</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/store')}>
                <Coins className="ml-2 h-4 w-4" />
                <span>شحن Zizo</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="text-red-600">
                <LogOut className="ml-2 h-4 w-4" />
                <span>تسجيل الخروج</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
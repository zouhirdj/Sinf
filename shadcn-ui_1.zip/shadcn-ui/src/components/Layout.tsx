import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, ShoppingBag, MessageCircle, User, LogOut, Coins } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, logout } = useAuth();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-[#4CD964] text-white sticky top-0 z-50 shadow-md">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                <span className="text-[#4CD964] font-bold text-xl">S</span>
              </div>
              <span className="text-xl font-bold">صِنف</span>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 bg-white/20 px-3 py-1.5 rounded-full">
                <Coins className="w-5 h-5 text-[#FFC400]" />
                <span className="font-bold">{user?.zizoBalance || 0}</span>
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="text-white hover:bg-white/20"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 pb-20">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-around py-3">
            <Link
              to="/"
              className={`flex flex-col items-center gap-1 ${
                isActive('/') ? 'text-[#4CD964]' : 'text-gray-600'
              }`}
            >
              <Home className="w-6 h-6" />
              <span className="text-xs">الرئيسية</span>
            </Link>
            
            <Link
              to="/store"
              className={`flex flex-col items-center gap-1 ${
                isActive('/store') ? 'text-[#4CD964]' : 'text-gray-600'
              }`}
            >
              <ShoppingBag className="w-6 h-6" />
              <span className="text-xs">المتجر</span>
            </Link>
            
            <Link
              to="/chats"
              className={`flex flex-col items-center gap-1 ${
                isActive('/chats') ? 'text-[#4CD964]' : 'text-gray-600'
              }`}
            >
              <MessageCircle className="w-6 h-6" />
              <span className="text-xs">المحادثات</span>
            </Link>
            
            <Link
              to="/profile"
              className={`flex flex-col items-center gap-1 ${
                isActive('/profile') ? 'text-[#4CD964]' : 'text-gray-600'
              }`}
            >
              <User className="w-6 h-6" />
              <span className="text-xs">الملف الشخصي</span>
            </Link>
          </div>
        </div>
      </nav>
    </div>
  );
};
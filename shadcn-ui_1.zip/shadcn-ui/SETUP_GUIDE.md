# دليل إعداد منصة صِنف (Sinf Platform Setup Guide)

## 🚀 نظرة عامة

منصة صِنف هي منصة اجتماعية ذكية مبنية بتقنيات حديثة:
- **Frontend**: React + TypeScript + Tailwind CSS + shadcn/ui
- **Backend**: Supabase (PostgreSQL + Auth + Real-time)
- **Styling**: RTL Arabic support with Cairo font
- **Theme**: Green (#4CD964) with Zizo yellow (#FFC400)

---

## 📋 المتطلبات الأساسية

1. **Node.js** (v18 or higher)
2. **pnpm** (v8 or higher)
3. **Supabase Account** (free tier works)

---

## 🔧 خطوات الإعداد

### 1. إعداد Supabase

#### أ. إنشاء مشروع جديد
1. اذهب إلى [Supabase Dashboard](https://app.supabase.com)
2. انقر على "New Project"
3. اختر اسم المشروع وكلمة المرور للقاعدة
4. انتظر حتى يتم إنشاء المشروع (2-3 دقائق)

#### ب. تشغيل SQL Setup Script
1. اذهب إلى **SQL Editor** في لوحة التحكم
2. انقر على "New Query"
3. انسخ محتوى ملف `database-setup.sql` بالكامل
4. الصق في المحرر واضغط "Run"
5. تأكد من ظهور رسالة النجاح

#### ج. تفعيل Email Authentication
1. اذهب إلى **Authentication > Providers**
2. فعّل "Email" provider
3. (اختياري) خصص قوالب البريد الإلكتروني

#### د. الحصول على API Keys
1. اذهب إلى **Settings > API**
2. انسخ:
   - `Project URL` (مثال: https://xxxxx.supabase.co)
   - `anon public` key

### 2. إعداد المشروع المحلي

```bash
# 1. انتقل إلى مجلد المشروع
cd /workspace/shadcn-ui

# 2. انسخ ملف البيئة
cp .env.example .env

# 3. افتح .env وأضف بيانات Supabase
# VITE_SUPABASE_URL=your_project_url
# VITE_SUPABASE_ANON_KEY=your_anon_key

# 4. ثبت المكتبات
pnpm install

# 5. شغّل المشروع
pnpm run dev
```

### 3. إضافة بطاقات الشحن (اختياري)

لإضافة بطاقات شحن Zizo، شغّل هذا SQL في Supabase:

```sql
-- إضافة بطاقات شحن للتجربة
INSERT INTO app_fcb82_recharge_cards (code, points) VALUES
    ('z50-TEST-001', 50),
    ('z50-TEST-002', 50),
    ('z100-TEST-001', 100),
    ('z100-TEST-002', 100),
    ('z200-TEST-001', 200);
```

أو استخدم الأكواد الموجودة في الملف الأصلي (1000 كود لكل فئة).

---

## 🎯 الميزات المتاحة

### ✅ تم التنفيذ
- [x] نظام تسجيل الدخول والتسجيل
- [x] الصفحة الرئيسية (Feed) مع المنشورات
- [x] إنشاء منشورات (حكمة، قصة، خدمة)
- [x] الإعجاب والتعليق على المنشورات
- [x] نظام نقاط Zizo
- [x] شحن البطاقات
- [x] الملف الشخصي
- [x] واجهة عربية RTL
- [x] تصميم أخضر مع شعار Sinf و Zizo

### ❌ غير مُنفذ (للمستقبل)
- [ ] نظام البوتات (600 حساب)
- [ ] المتجر الرقمي (شراء/بيع)
- [ ] الدردشة الفورية
- [ ] بوابات الدفع (PayPal, Stripe, BaridiMob)
- [ ] الإشعارات الفورية
- [ ] لوحة الإدارة

---

## 📱 الاستخدام

### تسجيل حساب جديد
1. افتح المتصفح على `http://localhost:5173`
2. انقر "سجل الآن"
3. أدخل البيانات (الاسم، البريد، الهاتف، كلمة المرور)
4. سيتم إنشاء الحساب مع 30 نقطة مبدئية

### نشر منشور
1. في الصفحة الرئيسية، اكتب محتوى المنشور
2. اختر النوع (حكمة/قصة/خدمة)
3. اضغط "نشر"

### شحن نقاط Zizo
1. اذهب إلى "المتجر" من القائمة العلوية
2. أدخل كود الشحن (مثال: z50-TEST-001)
3. اضغط "شحن الآن"
4. سيتم إضافة النقاط فوراً

---

## 🗂️ هيكل المشروع

```
src/
├── components/
│   ├── auth/           # مكونات تسجيل الدخول والتسجيل
│   ├── feed/           # مكونات المنشورات والتعليقات
│   ├── layout/         # الهيدر والتخطيط الرئيسي
│   ├── points/         # مكونات نظام النقاط
│   └── ui/             # مكونات shadcn/ui
├── lib/
│   ├── supabase.ts     # إعداد Supabase وdatabase helpers
│   ├── auth-store.ts   # Zustand store للمصادقة
│   └── utils.ts        # وظائف مساعدة
├── pages/
│   ├── Login.tsx       # صفحة تسجيل الدخول
│   ├── Register.tsx    # صفحة التسجيل
│   ├── Feed.tsx        # الصفحة الرئيسية
│   ├── Profile.tsx     # الملف الشخصي
│   └── Store.tsx       # متجر الشحن
├── types/
│   └── index.ts        # TypeScript types
└── App.tsx             # المكون الرئيسي
```

---

## 🎨 الألوان والتصميم

### الألوان الرئيسية
- **Primary Green**: `#4CD964` - الأزرار، الروابط، العناصر التفاعلية
- **Zizo Yellow**: `#FFC400` - نقاط Zizo فقط
- **Dark Gray**: `#2E2E2E` - النصوص
- **Light Gray**: `#F6F7F8` - الخلفيات

### الخطوط
- **Arabic**: Cairo (من Google Fonts)
- **English**: Poppins fallback

---

## 🔒 الأمان

- ✅ Row Level Security (RLS) مفعّل على جميع الجداول
- ✅ المستخدمون يمكنهم فقط تعديل بياناتهم
- ✅ المنشورات محمية (حذف فقط من المالك)
- ✅ بطاقات الشحن محمية من إعادة الاستخدام

---

## 🐛 استكشاف الأخطاء

### خطأ: "JWT could not be decoded"
- تأكد من إضافة `VITE_SUPABASE_URL` و `VITE_SUPABASE_ANON_KEY` في `.env`
- أعد تشغيل السيرفر بعد تعديل `.env`

### خطأ: "relation does not exist"
- تأكد من تشغيل `database-setup.sql` في Supabase
- تحقق من أن جميع الجداول موجودة في **Database > Tables**

### خطأ: "Failed to fetch"
- تحقق من اتصال الإنترنت
- تأكد من أن Supabase project URL صحيح

---

## 📞 الدعم

للمساعدة أو الأسئلة:
- راجع [Supabase Documentation](https://supabase.com/docs)
- راجع [shadcn/ui Documentation](https://ui.shadcn.com)

---

## 📄 الترخيص

هذا المشروع تجريبي (MVP) لأغراض التطوير والاختبار.

---

**تم بناء المشروع بواسطة MetaGPTX (MGX) Platform** 🚀